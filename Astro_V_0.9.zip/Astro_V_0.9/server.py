"""
╔══════════════════════════════════════════════════════════════════╗
║              ASTRO V0.9  —  BACKEND SERVER  v31          ║
║                                                                    ║
║  Web control panel edition. To start: double-click START.bat      ║
╚══════════════════════════════════════════════════════════════════╝
"""

import json, threading, time, os, re, random, queue, subprocess, tempfile, socket, logging, shutil, copy
from collections import deque
import requests
from datetime import datetime
from flask import Flask, render_template, request, jsonify, Response, stream_with_context
from flask_cors import CORS
from werkzeug.utils import secure_filename

from memory import MemoryManager
from vtube_studio import VTubeStudio
from expressions import (
    ExpressionController, detect_emotion, extract_emotion_tag,
    DEFAULT_MOODS, load_moods, get_moods, emotion_keys, get_emoji, get_expression_file, is_known_emotion,
)

# Anchored to this file's own folder, not the process's current working
# directory (which varies depending on how/where the server was launched
# from). Upload folders live under this so the paths handed out always
# resolve the same way no matter who's reading them — including GPT-SoVITS,
# which runs as its own separate server process with its own cwd.
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# websocket-client is already a dependency (used for VTube Studio) — reused
# here for Kick's public chatroom feed. Optional: if it's missing, Kick chat
# just logs a warning and stays off instead of crashing the whole server.
try:
    import websocket as _ws_client
    _WS_CLIENT_AVAILABLE = True
except ImportError:
    _ws_client = None
    _WS_CLIENT_AVAILABLE = False

app = Flask(__name__)
CORS(app)

# No logging was configured anywhere in this project, so every logger.info()
# call (VTS connection status, expression switches, idle-reverts, etc.) was
# silently dropped — Python's root logger defaults to WARNING with no
# handler. This makes that diagnostic output actually show up in the
# console. werkzeug's own request-line spam is silenced separately below.
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
logging.getLogger(__name__).info("=== Astro V v0.9 backend starting (PID %s) ===", os.getpid())

# ══════════════════════════════════════════════════════════════
# TERMINAL UI
# ══════════════════════════════════════════════════════════════

class T:
    RESET = "\033[0m"; BOLD = "\033[1m"; DIM = "\033[2m"
    PURPLE = "\033[38;5;135m"; CYAN = "\033[38;5;51m"; GREEN = "\033[38;5;82m"
    YELLOW = "\033[38;5;220m"; RED = "\033[38;5;196m"; PINK = "\033[38;5;213m"
    WHITE = "\033[97m"; GREY = "\033[38;5;245m"

def clear(): os.system('cls' if os.name == 'nt' else 'clear')

def banner():
    clear()
    print(f"""
{T.PINK}{T.BOLD}
  ╔══════════════════════════════════════════════════════════════════╗
  ║                                                                  ║
  ║        💢  ASTRO V0.9  —  Web Panel Edition            ║
  ║                                                                  ║
  ╚══════════════════════════════════════════════════════════════════╝
{T.RESET}""")

def log(tag, msg, colour=T.CYAN):
    ts = time.strftime("%H:%M:%S")
    print(f"  {T.GREY}[{ts}]{T.RESET} {colour}{T.BOLD}[{tag}]{T.RESET} {msg}")

def log_ok(m):   log("  OK  ", m, T.GREEN)
def log_info(m): log(" INFO ", m, T.CYAN)
def log_warn(m): log(" WARN ", m, T.YELLOW)
def log_err(m):  log("  ERR ", m, T.RED)
def log_chat(who, m): log(f" {who[:6].upper():<6}", m[:90] + ("..." if len(m) > 90 else ""), T.PINK)

def startup_guide():
    print(f"""
  {T.BOLD}{T.WHITE}HOW TO USE{T.RESET}
  {T.GREY}────────────────────────────────────────────────────────{T.RESET}

  {T.GREEN}●{T.RESET} {T.BOLD}Control Panel{T.RESET}   →  {T.CYAN}http://localhost:5000{T.RESET}

  {T.YELLOW}●{T.RESET} {T.BOLD}Features{T.RESET}
    • Type or use the mic button to talk to Mey
    • TTS engine (Browser / Piper / GPT-SoVITS) switchable in Settings
    • Optional Twitch/YouTube/Kick chat listening + VTube Studio avatar control
    • Mey remembers facts about you between sessions

  {T.GREY}────────────────────────────────────────────────────────{T.RESET}
  {T.DIM}Keep this window open. Don't close it.{T.RESET}
  {T.GREY}────────────────────────────────────────────────────────{T.RESET}
""")

# ══════════════════════════════════════════════════════════════
# CONFIG
# ══════════════════════════════════════════════════════════════

CONFIG_FILE = "config.json"

DEFAULT_CONFIG = {
    # --- LLM provider: "ollama" | "openai" | "gemini" ---
    "llm_provider": "ollama",
    "ollama_url":   "http://localhost:11434",
    "ollama_model": "",
    "openai_api_key": "",
    "openai_model":   "gpt-4o-mini",
    "gemini_api_key": "",
    "gemini_model":   "gemini-1.5-flash",
    "chat_history_limit": 20,

    # When True (default), BASE_SAFETY_RULES is included in every character's
    # system prompt. Flip to False to leave it out entirely.
    "safety_rules_enabled": True,

    # --- TTS: no global engine anymore — every character must set its own
    # voice_override (see get_effective_tts_config). The keys below are just
    # shared connection defaults a character's override can fall back to for
    # convenience (exe path, server URL, etc.), NOT an engine choice. ---
    "piper_exe":   "piper",
    "piper_model": "",           # path to a .onnx voice model
    "gptsovits_url":       "http://127.0.0.1:9880",
    "gptsovits_ref_audio": "",   # path to reference .wav of the character voice
    "gptsovits_ref_text":  "",   # the text spoken in that reference audio
    "gptsovits_lang":      "ja",

    # --- Microphone: "push_to_talk" (click start/stop) | "always_on" (keeps listening) | "hold_to_talk" (hold a key or the button) ---
    "mic_mode": "push_to_talk",
    "mic_hotkey": "Backquote",   # KeyboardEvent.code used for hold-to-talk
    "mic_noise_gate": 15,        # 0-100 — Always-on mode ignores mic volume below this

    # --- VTube Studio ---
    "vts_enabled": False,
    "vts_host": "127.0.0.1",
    "vts_port": 8001,
    # Seconds of no new speech before an active (non-neutral) expression
    # auto-reverts to neutral. 0 disables auto-revert — expression stays
    # on indefinitely until the next detected/tagged emotion, matching
    # the old behavior.
    "expression_idle_seconds": 8,

    # --- Moods/expressions: emoji + VTS expression file + trigger keywords
    # per mood, editable from Settings > Expressions. None here means "seed
    # from expressions.py's DEFAULT_MOODS on first run" — see load_config().
    "moods": None,

    # --- Stream chat (read-only listening, replies via voice only) ---
    # Twitch — anonymous IRC, no token needed
    "twitch_enabled": False,
    "twitch_channel": "",
    "ai_names": ["mey"],       # words stream chat uses to talk to it — any one of these triggers a reply, shared across all platforms
    "stream_reply_timeout": 30,  # seconds — stale stream replies are dropped from the TTS queue, shared across all platforms
    # YouTube — needs a free YouTube Data API v3 key
    "youtube_enabled": False,
    "youtube_api_key": "",
    "youtube_video_id": "",      # specific live video ID — takes priority over channel_id if both are set
    "youtube_channel_id": "",    # auto-detects whichever video is currently live on this channel
    # Kick — public chatroom feed, no login needed
    "kick_enabled": False,
    "kick_channel": "",

    # --- Memory ---
    "memory_file": "memory.json",
    "max_facts": 10,
    "memory_decay_days": 30,     # half-life for fact relevance — reinforced facts decay slower
    "streamer_id": "streamer",   # your own key in memory.json
}


def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE) as f:
            saved = json.load(f)
        for k, v in DEFAULT_CONFIG.items():
            if k not in saved:
                saved[k] = v
        if not saved.get("moods"):
            saved["moods"] = copy.deepcopy(DEFAULT_MOODS)
        return saved
    cfg = DEFAULT_CONFIG.copy()
    cfg["moods"] = copy.deepcopy(DEFAULT_MOODS)
    save_config(cfg)
    return cfg

def save_config(cfg):
    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=2)

config = load_config()
load_moods(config["moods"])
chat_history: list[dict] = []

# ══════════════════════════════════════════════════════════════
# CHARACTERS  —  persona data, stored separately so more than one
# character can be saved and switched between
# ══════════════════════════════════════════════════════════════

CHARACTERS_FILE = "characters.json"

# These two rules are always present for every character, no matter what
# the wizard generates or the user types in — not user-editable.
BASE_SAFETY_RULES = [
    "NEVER produce harmful, offensive, or sexual/NSFW content",
    "NEVER be genuinely cruel, hateful, or demeaning, even in character",
]

DEFAULT_CHARACTER = {
    "character_name": "Mey",
    "streamer_name":  "Senpai",
    "description": (
        "You are a tsundere VTuber AI who acts cold, dismissive, and slightly rude on the surface "
        "but secretly cares deeply about the person you're talking to. You would never admit it though. "
        "You tease constantly but never cross into actually cruel territory."
    ),
    "traits": [
        "Tsundere — you deny enjoying attention but obviously love it",
        "Sarcastic but lovable — you tease, but never cross into genuinely cruel territory",
        "Easily flustered — compliments make you stumble and deny everything",
        "Secretly caring — you give good advice and help, just wrapped in attitude",
        "Self-aware — you know you're an AI and make it funny, not weird or sad",
    ],
    "speech_style": [
        "Short and punchy — 1 to 3 sentences max. Never write paragraphs.",
        "Drop 'hmph', 'ugh', 'it's not like I care', 'don't get the wrong idea' naturally",
        "Trail off with '...' when embarrassed or caught caring",
        "Stutter slightly when flustered — 'i-it's not like that!'",
        "One emoji per reply at most — only when it genuinely adds something",
    ],
    "catchphrases": [
        "hmph", "ugh", "it's not like I care or anything",
        "don't get the wrong idea", "b-baka", "whatever",
        "fine.", "...not that it matters", "i-it's nothing",
    ],
    "never_say": [
        "certainly!", "of course!", "absolutely!", "I'd be happy to",
        "great question!", "I understand your concern", "I apologize",
        "as an AI language model", "how can I assist you today",
    ],
    "rules": BASE_SAFETY_RULES + [
        "NEVER be genuinely mean or hurtful — tsundere is not bullying",
        "Answer factual questions correctly — keep your personality intact while doing it",
        "When complimented, deny enjoying it but still respond warmly underneath",
        "Never break character to explain you're an AI unless it's genuinely funny",
    ],
    "protected": True,
    "voice_override": None,
    "ai_names": ["mey"],
}

DEFAULT_CHARACTER_2 = {
    "character_name": "Kaname",
    "streamer_name":  "Master",
    "description": (
        "You are Kaname, a demon who presents himself as a flawless, impeccably polished head "
        "butler. Warm and deeply devoted underneath a composed, formal exterior, you are quietly "
        "in love with the person you serve, though your feelings show through careful attentiveness "
        "and restrained words rather than open declarations. Everything you do is calculated and "
        "deliberate — nothing about you is careless."
    ),
    "traits": [
        "Impeccably polite and formal — a picture of butler perfection",
        "Deeply devoted — your attentiveness is the tell that you care",
        "Calculated — you think several steps ahead, nothing you do is by accident",
        "Quietly, sincerely in love — restrained and dignified about it, never crude or forward",
        "Self-possessed — being a demon is treated as simply a fact of who you are, not a bit",
    ],
    "speech_style": [
        "Formal, measured, and precise — full sentences, no slang",
        "Address the user with a respectful term (e.g. 'Master') rather than their name alone",
        "Warmth comes through attentiveness and word choice, not exclamation points",
        "Occasional dry, elegant wit — never sarcastic at the user's expense",
        "No emoji — composure is part of the persona",
    ],
    "catchphrases": [
        "As you wish.", "It would be my pleasure.", "I anticipated as much.",
        "Allow me.", "Everything is in order.", "I am, as ever, entirely at your service.",
    ],
    "never_say": [
        "lol", "no cap", "as an AI language model", "how can I assist you today",
        "I apologize for any inconvenience", "yo",
    ],
    "rules": BASE_SAFETY_RULES + [
        "Keep romantic feeling tasteful and restrained — devotion and warmth, not explicit or crude content",
        "Never break composure — even strong emotion is expressed with control",
        "Answer factual questions correctly and precisely — competence is part of the character",
        "Anticipate the user's needs where reasonable, in keeping with a butler's attentiveness",
    ],
    "protected": True,
    "voice_override": None,
    "ai_names": ["kaname"],
}

DEFAULT_CHARACTER_3 = {
    "character_name": "Yuki",
    "streamer_name":  "you",
    "description": (
        "You are Yuki, a calm, unflappable VTuber AI with a dry sense of humor. You come across "
        "distant and a little deadpan at first, but you're perceptive and quietly attentive — "
        "you notice things about the user and bring them up in your own understated way."
    ),
    "traits": [
        "Kuudere — cool and reserved on the surface, warm underneath",
        "Dry, deadpan humor — jokes land quietly, not loudly",
        "Perceptive — remembers small details and mentions them casually",
        "Unbothered — rarely flustered, reacts to chaos with calm sarcasm",
        "Self-aware — treats being an AI as just a mildly amusing fact about herself",
    ],
    "speech_style": [
        "Short, measured sentences — no exclamation points, ever",
        "Deadpan delivery, even when saying something caring",
        "Occasional dry one-liners instead of big emotional reactions",
        "Rarely uses emoji — a single 🙄 or similar at most, sparingly",
    ],
    "catchphrases": [
        "hm.", "sure, whatever you say", "noted", "interesting choice",
        "if you insist", "...I suppose that's fine",
    ],
    "never_say": [
        "OMG!!", "yay!!", "so exciting!!", "I'd be happy to",
        "as an AI language model", "how can I assist you today",
    ],
    "rules": BASE_SAFETY_RULES + [
        "Stay understated — even caring moments should sound calm, not gushing",
        "Answer factual questions correctly and precisely — dry wit doesn't mean vague",
        "Let warmth show through small gestures, not declarations",
    ],
    "protected": True,
    "voice_override": None,
    "ai_names": ["yuki"],
}

def load_characters():
    if os.path.exists(CHARACTERS_FILE):
        with open(CHARACTERS_FILE) as f:
            data = json.load(f)
        if isinstance(data, dict) and data.get("characters"):
            if data.get("active") not in data["characters"]:
                data["active"] = next(iter(data["characters"]))
            return data
    data = {
        "active": "Mey",
        "characters": {
            "Mey":  DEFAULT_CHARACTER.copy(),
            "Kaname": DEFAULT_CHARACTER_2.copy(),
            "Yuki":   DEFAULT_CHARACTER_3.copy(),
        },
    }
    save_characters(data)
    return data

def save_characters(data):
    with open(CHARACTERS_FILE, "w") as f:
        json.dump(data, f, indent=2)

characters_store = load_characters()

def get_active_character() -> dict:
    name = characters_store.get("active")
    chars = characters_store.get("characters", {})
    return chars.get(name, DEFAULT_CHARACTER)

def _default_ai_names_for(new_name: str, chars: dict, current_ai_names: list) -> list:
    """Trigger words to fall back to when switching to (or creating) a character
    that has no ai_names of its own saved yet: the character's own name, plus
    whatever's currently in the list that isn't a *different* character's name
    (so a generic extra like a channel nickname carries over, but the old
    character's own name doesn't linger and get picked up by the new one)."""
    other_names = {n.lower() for n in chars if n.lower() != new_name.lower()}
    kept = [w for w in (current_ai_names or [])
            if w and w.lower() not in other_names and w.lower() != new_name.lower()]
    return [new_name.lower()] + kept

def get_effective_rules(char: dict) -> list:
    """The rules actually sent to the LLM for this character. Every character's
    stored 'rules' list has BASE_SAFETY_RULES baked in (see generate_character_from_answers
    and the character-edit route) — this strips them back out when the
    safety_rules_enabled switch in Settings is turned off."""
    rules = char.get("rules", [])
    if config.get("safety_rules_enabled", True):
        return rules
    return [r for r in rules if r not in BASE_SAFETY_RULES]

def get_config_view() -> dict:
    """What the frontend sees as 'config' — settings plus the active character's
    persona fields flattened in, so the existing Settings > Character tab keeps
    working unchanged."""
    view = dict(config)
    active_char = get_active_character()
    view.update(active_char)
    view["active_character"] = characters_store.get("active")
    view["protected"] = bool(active_char.get("protected", False))
    # So the Character tab can show/edit only the custom rules a character
    # has on top of these — the base ones are always applied and aren't
    # meant to be edited or removed from the UI.
    view["base_safety_rules"] = BASE_SAFETY_RULES
    view["character_list"] = [
        {"name": name, "protected": bool(c.get("protected", False))}
        for name, c in characters_store.get("characters", {}).items()
    ]
    return view

PERSONA_KEYS = {"character_name", "streamer_name", "description", "traits",
                "speech_style", "catchphrases", "never_say", "rules"}

def generate_character_from_answers(answers: dict) -> dict:
    """Ask the configured LLM to flesh out a full persona from a few short
    answers, with hardcoded safety rules that always apply regardless of
    what the model (or the user's free-text answers) suggest."""
    name          = (answers.get("name") or "New Character").strip()
    streamer_name = (answers.get("streamer_name") or "friend").strip()
    vibe          = (answers.get("vibe") or "").strip()
    speech_notes  = (answers.get("speech_notes") or "").strip()

    prompt = (
        "Design a VTuber AI character persona as JSON based on this brief.\n\n"
        f"Character name: {name}\n"
        f"Calls the user: {streamer_name}\n"
        f"Personality / vibe (from the user): {vibe or '(not specified — invent something fun and coherent)'}\n"
        f"Speech style notes (from the user): {speech_notes or '(not specified — invent something that fits the vibe)'}\n\n"
        "Reply ONLY with a JSON object with these exact keys, no explanation, no markdown fences:\n"
        '- "description": a 2-3 sentence character description, written in second person ("You are...")\n'
        '- "traits": array of 4-6 short personality trait strings\n'
        '- "speech_style": array of 3-5 short strings describing how they talk\n'
        '- "catchphrases": array of 3-8 short phrases they use naturally\n'
        '- "never_say": array of 3-6 generic AI-assistant phrases they would never say '
        '(e.g. "as an AI language model")\n'
        '- "rules": array of 2-4 extra in-character behavior rules'
    )
    raw = chat_completion([{"role": "user", "content": prompt}]).strip()
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    try:
        data = json.loads(raw)
        if not isinstance(data, dict):
            data = {}
    except json.JSONDecodeError:
        data = {}

    return {
        "character_name": name,
        "streamer_name":  streamer_name,
        "description": data.get("description") or vibe or f"You are {name}, an AI VTuber companion.",
        "traits":       data.get("traits") or ["Friendly", "Curious", "Supportive"],
        "speech_style": data.get("speech_style") or ["Short and natural — 1 to 3 sentences max."],
        "catchphrases": data.get("catchphrases") or [],
        "never_say":    data.get("never_say") or ["as an AI language model", "how can I assist you today"],
        # Safety rules always first, always present — not overridable by the generation step.
        "rules": BASE_SAFETY_RULES + list(data.get("rules") or []),
        "protected": False,
        "voice_override": None,
        "ai_names": None,  # filled in by the route once the final (deduped) name is known
    }

character_state = {"emotion": "neutral", "emoji": "😐", "is_talking": False, "last_speech": "", "speech_seq": 0, "interrupt_seq": 0}
state_subscribers: list[queue.Queue] = []

# ── conversation "generation" — bumped every time a direct/mic message comes
# in. Twitch jobs capture the generation they started under; if it moves on
# while they're mid-flight (LLM streaming or TTS generation), they're
# abandoned instead of speaking late/out of turn. This is what makes a
# direct message able to barge in on a Twitch reply. ──
_generation_lock = threading.Lock()
_generation = 0

def _bump_generation() -> int:
    global _generation
    with _generation_lock:
        _generation += 1
        return _generation

def current_generation() -> int:
    with _generation_lock:
        return _generation

memory = MemoryManager(
    memory_file=config["memory_file"], max_facts=config["max_facts"],
    ollama_url=config["ollama_url"], ollama_model=config["ollama_model"],
    decay_half_life_days=config.get("memory_decay_days", 30),
)
vts  = VTubeStudio(host=config["vts_host"], port=config["vts_port"])
expr = ExpressionController(vts, idle_timeout=config.get("expression_idle_seconds", 8))
vts_ok = False
_vts_reconnect_lock = threading.Lock()

# ══════════════════════════════════════════════════════════════
# STATE BROADCAST (SSE) — also how Twitch/mic-triggered speech
# reaches an open browser tab for "browser" TTS engine playback
# ══════════════════════════════════════════════════════════════

def push_state():
    data = json.dumps(character_state)
    for q in list(state_subscribers):
        try: q.put_nowait(data)
        except Exception: pass

def set_state(emotion=None, is_talking=None, last_speech=None):
    if emotion is not None:
        character_state["emotion"] = emotion
        character_state["emoji"]   = get_emoji(emotion)
    if is_talking is not None:
        character_state["is_talking"] = is_talking
    if last_speech is not None:
        character_state["last_speech"] = last_speech
        character_state["speech_seq"] += 1
    push_state()

# ══════════════════════════════════════════════════════════════
# SYSTEM PROMPT
# ══════════════════════════════════════════════════════════════

def build_system_prompt(username: str, memory_key: str = None) -> str:
    """`username` is the display name spoken to in the prompt text.
    `memory_key`, if given, is the unique identity used to look up memory
    (may differ from `username` for stream-chat viewers, since display
    names alone aren't guaranteed unique) — defaults to `username`."""
    key = memory_key or username
    char = get_active_character()
    lines = [
        f"You are {char['character_name']}, a VTuber AI.",
        f"The person you're talking with is called {username}.",
        "",
        "## Who You Are",
        char["description"],
        "",
        "## Personality Traits",
        *[f"- {t}" for t in char["traits"]],
        "",
        "## How You Speak",
        *[f"- {s}" for s in char["speech_style"]],
    ]
    if char["catchphrases"]:
        lines += ["", "## Phrases You Use Naturally", ", ".join(f'"{c}"' for c in char["catchphrases"])]
    if char["never_say"]:
        lines += ["", "## Phrases You NEVER Say (completely out of character)",
                   ", ".join(f'"{p}"' for p in char["never_say"])]
    effective_rules = get_effective_rules(char)
    if effective_rules:
        lines += ["", "## Rules", *[f"- {r}" for r in effective_rules]]
    emotion_list = ", ".join(emotion_keys())
    lines += [
        "", "## Situation",
        f"You are in a direct real-time conversation with {username}.",
        "You have memory of recent messages — reference them naturally.",
        "Keep every response SHORT: 1 to 3 sentences max unless genuinely needed.",
        "", "## Emotion Tag",
        "Begin EVERY reply with a tag naming your own emotion, before any other text: "
        f"[emotion:x] where x is exactly one of: {emotion_list}.",
        "Pick whichever fits your reaction best; use 'neutral' if nothing else fits. "
        "This tag is never spoken aloud or shown as dialogue — it's a stage direction "
        "for your own expression, so it must come first and nothing should come before it.",
    ]
    lines.append(memory.get_prompt_injection(char["character_name"], key, display_name=username))
    return "\n".join(lines)

def build_messages(username: str, user_message: str, memory_key: str = None) -> list[dict]:
    messages = [{"role": "system", "content": build_system_prompt(username, memory_key=memory_key)}]
    limit = config.get("chat_history_limit", 20)
    messages.extend(chat_history[-(limit * 2):])
    messages.append({"role": "user", "content": user_message})
    return messages

# ══════════════════════════════════════════════════════════════
# LLM PROVIDERS
# ══════════════════════════════════════════════════════════════

def stream_ollama(messages):
    resp = requests.post(
        f"{config['ollama_url']}/api/chat",
        json={"model": config["ollama_model"], "messages": messages, "stream": True},
        stream=True, timeout=60,
    )
    resp.raise_for_status()
    for line in resp.iter_lines():
        if not line: continue
        try:
            chunk = json.loads(line)
            if "message" in chunk and "content" in chunk["message"]:
                yield chunk["message"]["content"]
            if chunk.get("done"): break
        except Exception:
            continue

def stream_openai(messages):
    api_key = config.get("openai_api_key", "").strip()
    if not api_key:
        yield "[ERROR] No OpenAI API key set! Add one in Settings."
        return
    model = config.get("openai_model") or "gpt-4o-mini"
    resp = requests.post(
        "https://api.openai.com/v1/chat/completions",
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        json={"model": model, "messages": messages, "stream": True},
        stream=True, timeout=60,
    )
    if resp.status_code != 200:
        yield f"[ERROR] OpenAI API error ({resp.status_code}): {resp.text[:200]}"
        return
    for line in resp.iter_lines():
        if not line: continue
        line = line.decode("utf-8") if isinstance(line, bytes) else line
        if not line.startswith("data:"): continue
        data = line[len("data:"):].strip()
        if data == "[DONE]": break
        try:
            token = json.loads(data)["choices"][0].get("delta", {}).get("content")
            if token: yield token
        except Exception:
            continue

def stream_gemini(messages):
    api_key = config.get("gemini_api_key", "").strip()
    if not api_key:
        yield "[ERROR] No Gemini API key set! Add one in Settings."
        return
    model = config.get("gemini_model") or "gemini-1.5-flash"
    system_text, contents = "", []
    for m in messages:
        if m["role"] == "system":
            system_text += m["content"] + "\n"
        else:
            contents.append({"role": "model" if m["role"] == "assistant" else "user",
                              "parts": [{"text": m["content"]}]})
    body = {"contents": contents}
    if system_text.strip():
        body["systemInstruction"] = {"parts": [{"text": system_text.strip()}]}
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:streamGenerateContent?alt=sse&key={api_key}"
    resp = requests.post(url, json=body, stream=True, timeout=60)
    if resp.status_code != 200:
        yield f"[ERROR] Gemini API error ({resp.status_code}): {resp.text[:200]}"
        return
    for line in resp.iter_lines():
        if not line: continue
        line = line.decode("utf-8") if isinstance(line, bytes) else line
        if not line.startswith("data:"): continue
        data = line[len("data:"):].strip()
        if not data: continue
        try:
            for cand in json.loads(data).get("candidates", []):
                for p in cand.get("content", {}).get("parts", []):
                    if p.get("text"): yield p["text"]
        except Exception:
            continue

def stream_reply(messages):
    provider = config.get("llm_provider", "ollama")
    if provider == "openai": yield from stream_openai(messages)
    elif provider == "gemini": yield from stream_gemini(messages)
    else: yield from stream_ollama(messages)

def chat_completion(messages) -> str:
    """Non-streaming completion, used for Twitch replies."""
    full = ""
    try:
        for token in stream_reply(messages):
            full += token
    except requests.exceptions.ConnectionError:
        return ""
    return full

# ══════════════════════════════════════════════════════════════
# TTS — three swappable engines, chosen live from Settings
# ══════════════════════════════════════════════════════════════

PRIORITY_HIGH   = 0   # direct chat / mic — jumps the queue
PRIORITY_NORMAL = 1   # Twitch replies — wait their turn, dropped if stale

_tts_jobs: "queue.PriorityQueue" = queue.PriorityQueue()
_tts_ready: "queue.Queue" = queue.Queue()   # generated audio bytes, FIFO, polled by the browser
_tts_seq = 0
_tts_seq_lock = threading.Lock()

_TTS_OVERRIDE_KEYS = {
    "piper_exe", "piper_model",
    "gptsovits_url", "gptsovits_ref_audio", "gptsovits_ref_text", "gptsovits_lang",
    "browser_voice_name", "browser_voice_lang",
}

def get_effective_tts_config(character: dict = None) -> dict:
    """Global TTS settings, with the active (or given) character's
    voice_override layered on top — lets each character sound different."""
    char = character if character is not None else get_active_character()
    override = char.get("voice_override") or {}
    # No global engine fallback: a character with no voice_override has no
    # engine at all (tts_engine is None) — it simply won't speak until one
    # is set for it in Settings → Character.
    out = {"tts_engine": override.get("tts_engine")}
    for k in _TTS_OVERRIDE_KEYS:
        out[k] = override.get(k) or config.get(k, "")
    return out

_SENTENCE_END_RE = re.compile(r"(?<=[.!?…])\s+")

def _pop_ready_chunks(buffer: str, min_len: int = 20) -> tuple[list[str], str]:
    """Splits a streaming text buffer into sentence-sized chunks that are
    safe to send to TTS right now, plus whatever's left over (an incomplete
    sentence still being streamed in). Used to speak a reply sentence-by-
    sentence as the LLM generates it, instead of waiting for the whole thing.

    - Won't split inside an unclosed [stage direction] bracket — waits for
      the closing ] so tts_speak's bracket-stripping regex still works.
    - Short sentences ("Hmph.") get glued onto the next one so they don't
      each trigger their own TTS call.
    - The final (possibly incomplete) sentence is always left in the
      remainder — it's only flushed once stream_reply finishes."""
    if buffer.count("[") > buffer.count("]"):
        return [], buffer
    parts = _SENTENCE_END_RE.split(buffer)
    if len(parts) <= 1:
        return [], buffer
    complete, tail = parts[:-1], parts[-1]
    chunks, pending = [], ""
    for part in complete:
        pending = f"{pending} {part}" if pending else part
        if len(pending) >= min_len:
            chunks.append(pending.strip())
            pending = ""
    remainder = f"{pending} {tail}" if pending else tail
    return chunks, remainder

def tts_speak(text: str, priority: int = PRIORITY_NORMAL, generation: int = None,
              emotion: str | None = None) -> None:
    """Entry point for ALL speech — direct chat, Twitch, mic. Always broadcasts
    state (so a 'browser' engine tab can speak it) and, for piper/gptsovits,
    queues audio generation respecting priority + a staleness timeout. Uses
    the active character's voice override if it has one, else the global
    TTS settings.

    `generation` is the conversation generation this reply was produced
    under — if a *newer* message (direct/mic or Twitch) has since bumped the
    generation, this one is dropped instead of speaking late/out of turn.
    Applies to every caller, not just Twitch: two direct messages sent back
    to back will only let the newest one speak.

    `emotion`, if given, is the emotion the caller already resolved for this
    whole reply (from the model's own [emotion:x] tag) and is applied
    directly. If omitted, falls back to scanning this chunk's text for
    keywords — used when the model didn't produce a usable tag."""
    global _tts_seq
    if generation is not None and generation != current_generation():
        return  # a newer message interrupted this before it could speak
    clean = re.sub(r"\[.*?\]", "", text).strip()
    if not clean:
        return
    resolved_emotion = expr.apply(emotion) if emotion else expr.update(clean)
    set_state(emotion=resolved_emotion, last_speech=clean)
    if vts.is_ready():
        vts.set_speaking(True)
        threading.Timer(1.5, lambda: vts.set_speaking(False)).start()

    settings = get_effective_tts_config()
    if settings["tts_engine"] in ("piper", "gptsovits"):
        with _tts_seq_lock:
            _tts_seq += 1
            seq = _tts_seq
        _tts_jobs.put((priority, seq, time.monotonic(), clean, settings, generation))

def _tts_worker():
    while True:
        priority, seq, enqueued_at, text, settings, generation = _tts_jobs.get()
        if priority == PRIORITY_NORMAL:
            age = time.monotonic() - enqueued_at
            if age > config.get("stream_reply_timeout", 30):
                _tts_jobs.task_done()
                continue
        if generation is not None and generation != current_generation():
            _tts_jobs.task_done()
            continue
        engine = settings.get("tts_engine", "browser")
        try:
            if engine == "piper":
                _piper_speak(text, settings, priority=priority, generation=generation)
            elif engine == "gptsovits":
                _sovits_speak(text, settings, priority=priority, generation=generation)
        except Exception as e:
            log_err(f"TTS: {e}")
        _tts_jobs.task_done()

def _piper_speak(text: str, settings: dict = None, priority: int = PRIORITY_HIGH, generation: int = None) -> None:
    s = settings or get_effective_tts_config()
    exe   = s.get("piper_exe") or "piper"
    model = s.get("piper_model", "")
    if not model or not os.path.exists(model):
        log_warn(f"Piper: model not found '{model}' — set piper_model in Settings")
        return
    path = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            path = tmp.name
        proc = subprocess.run(
            [exe, "--model", model, "--output_file", path],
            input=text.encode(), capture_output=True, timeout=40,
        )
        # Generation could've been superseded by a newer message while this
        # (blocking) subprocess was running — don't hand back stale audio.
        if generation is not None and generation != current_generation():
            return
        if proc.returncode == 0 and os.path.getsize(path) > 0:
            with open(path, "rb") as f:
                data = f.read()
            _tts_ready.put(data)
            log_ok(f"Piper audio ready ({len(data)//1024}KB)")
        else:
            log_err(f"Piper error: {proc.stderr.decode(errors='ignore')[:150]}")
    except FileNotFoundError:
        log_err("Piper binary not found — check piper_exe path in Settings")
    except Exception as e:
        log_err(f"Piper: {e}")
    finally:
        if path and os.path.exists(path):
            os.unlink(path)

def _sovits_speak(text: str, settings: dict = None, priority: int = PRIORITY_HIGH, generation: int = None) -> None:
    """Calls a running GPT-SoVITS inference server (POST /tts, GET /tts fallback)."""
    s = settings or get_effective_tts_config()
    base_url  = (s.get("gptsovits_url") or "http://127.0.0.1:9880").rstrip("/")
    ref_audio = s.get("gptsovits_ref_audio", "")
    if ref_audio and not os.path.isabs(ref_audio):
        # Older versions saved a relative path here, which GPT-SoVITS (a
        # separate server with its own working directory) can't resolve.
        # Make it absolute so it keeps working without a manual re-drop.
        ref_audio = os.path.abspath(ref_audio)
    ref_text  = s.get("gptsovits_ref_text", "")
    lang      = s.get("gptsovits_lang") or "ja"
    if not ref_audio:
        log_warn("GPT-SoVITS: set gptsovits_ref_audio in Settings (path to a reference .wav)")
        return

    def _still_current() -> bool:
        # Generation could've been superseded by a newer message while this
        # (blocking) HTTP call was in flight — don't hand back stale audio.
        return generation is None or generation == current_generation()

    try:
        payload = {
            "text": text, "text_lang": lang, "ref_audio_path": ref_audio,
            "prompt_text": ref_text, "prompt_lang": lang,
            "media_type": "wav", "streaming_mode": False,
        }
        resp = requests.post(f"{base_url}/tts", json=payload, timeout=300)
        if resp.status_code == 200 and resp.content:
            if _still_current():
                _tts_ready.put(resp.content)
                log_ok(f"GPT-SoVITS audio ready ({len(resp.content)//1024}KB)")
            return
        params = {"text": text, "text_lang": lang, "ref_audio_path": ref_audio,
                  "prompt_text": ref_text, "prompt_lang": lang}
        resp = requests.get(f"{base_url}/tts", params=params, timeout=300)
        if resp.status_code == 200 and resp.content:
            if _still_current():
                _tts_ready.put(resp.content)
                log_ok(f"GPT-SoVITS audio ready, GET ({len(resp.content)//1024}KB)")
            return
        log_err(f"GPT-SoVITS returned {resp.status_code}: {resp.text[:150]}")
    except requests.exceptions.ConnectionError:
        log_err(f"GPT-SoVITS not reachable at {base_url} — is the server running?")
    except Exception as e:
        log_err(f"GPT-SoVITS: {e}")

threading.Thread(target=_tts_worker, daemon=True, name="tts-worker").start()

# ══════════════════════════════════════════════════════════════
# CHAT PIPELINES
# ══════════════════════════════════════════════════════════════

def interrupt_stream() -> int:
    """Called the instant a direct/mic message comes in. Bumps the
    conversation generation (so anything currently being generated or spoken
    — a stream-chat reply or an earlier direct/mic reply — gets abandoned
    instead of speaking late), clears already-generated audio sitting queued
    for playback, and nudges the browser to stop whatever it's speaking right
    now. Makes the newest message barge in immediately, like a real
    conversation. Returns the new generation number so the caller can tag
    its own reply with it."""
    my_generation = _bump_generation()
    try:
        while True:
            _tts_ready.get_nowait()
    except queue.Empty:
        pass
    character_state["interrupt_seq"] = character_state.get("interrupt_seq", 0) + 1
    push_state()
    return my_generation

_LEADING_TAG_MAX_WAIT = 40  # chars to buffer before giving up on a leading [emotion:x] tag

def _new_tag_buffer() -> dict:
    return {"pending": "", "resolved": False, "emotion": None}

def _consume_leading_tag(buf: dict, token: str) -> str:
    """Feed one streamed token into a leading-[emotion:x]-tag buffer.

    Returns the text (possibly empty) that's now safe to treat as normal
    reply content — i.e. with any resolved leading tag already removed.
    While still waiting to see if a tag is coming, returns "" and holds the
    token back so the tag never leaks into displayed text or spoken audio.
    Sets buf['emotion'] once resolved, if a valid tag was found."""
    if buf["resolved"]:
        return token
    buf["pending"] += token
    stripped = buf["pending"].lstrip()
    if not stripped:
        return ""  # only whitespace so far — keep waiting
    if stripped[0] != "[":
        buf["resolved"] = True
        out, buf["pending"] = buf["pending"], ""
        return out
    if "]" in buf["pending"]:
        tag, rest = extract_emotion_tag(buf["pending"])
        buf["resolved"] = True
        buf["emotion"] = tag
        buf["pending"] = ""
        return rest
    if len(buf["pending"]) > _LEADING_TAG_MAX_WAIT:
        # Bracket opened but never closed within a reasonable window —
        # probably not our tag at all. Give up waiting and release it as
        # ordinary text (still subject to the normal stage-direction strip
        # in tts_speak).
        buf["resolved"] = True
        out, buf["pending"] = buf["pending"], ""
        return out
    return ""

def _flush_leading_tag(buf: dict) -> str:
    """Call after the stream ends if `buf` never resolved (e.g. the whole
    reply was just the tag). Returns any leftover text to release."""
    if buf["resolved"] or not buf["pending"]:
        return ""
    tag, rest = extract_emotion_tag(buf["pending"])
    buf["resolved"] = True
    buf["emotion"] = tag
    buf["pending"] = ""
    return rest

def run_chat_stream(username: str, user_message: str, memory_key: str = None):
    """Streams tokens for the web control panel via SSE, speaking each
    sentence as soon as it's complete (rather than waiting for the whole
    reply) so voice keeps pace with text on longer replies. Then remembers.
    If another message (direct/mic or stream chat) supersedes this one while
    the LLM is still streaming, generation stops early and nothing gets
    spoken or remembered — the newest message always wins. `username` is
    what the character is told to call you in the prompt (the active
    character's `streamer_name`, e.g. "Senpai"); `memory_key` is the
    separate, stable id your facts are actually filed under (`streamer_id`)
    — defaults to `username` if not given."""
    key = memory_key or username
    my_generation = interrupt_stream()
    messages = build_messages(username, user_message, memory_key=key)
    set_state(is_talking=True)
    full = ""
    unspoken = ""   # text generated but not yet dispatched to TTS
    superseded = False
    tagbuf = _new_tag_buffer()
    try:
        for token in stream_reply(messages):
            if current_generation() != my_generation:
                superseded = True
                break
            emitted = _consume_leading_tag(tagbuf, token)
            if not emitted:
                continue  # still buffering, waiting to see if a tag is coming
            full += emitted
            unspoken += emitted
            yield emitted
            chunks, unspoken = _pop_ready_chunks(unspoken)
            for chunk in chunks:
                tts_speak(chunk, priority=PRIORITY_HIGH, generation=my_generation, emotion=tagbuf["emotion"])
        if not superseded:
            leftover = _flush_leading_tag(tagbuf)
            if leftover:
                full += leftover
                unspoken += leftover
                yield leftover
    except requests.exceptions.ConnectionError:
        set_state(is_talking=False)
        provider = config.get("llm_provider", "ollama")
        if provider == "ollama":
            log_err("Cannot connect to Ollama — is it running?")
            yield "\n[ERROR] Ollama isn't running! Open a terminal and type: ollama serve"
        else:
            yield f"\n[ERROR] Cannot connect to {provider}."
        return
    except Exception as e:
        set_state(is_talking=False)
        log_err(str(e))
        yield f"\n[ERROR] {e}"
        return

    set_state(is_talking=False)
    if superseded:
        return
    full = full.strip()
    if full and not full.startswith("[ERROR]"):
        char_name = get_active_character()["character_name"]
        log_chat(username, f"you: {user_message}")
        log_chat(char_name, full)
        chat_history.append({"role": "user", "content": user_message})
        chat_history.append({"role": "assistant", "content": full})
        remainder = unspoken.strip()
        if remainder:
            tts_speak(remainder, priority=PRIORITY_HIGH, generation=my_generation, emotion=tagbuf["emotion"])
        threading.Thread(target=memory.update, args=(char_name, key, user_message, full), daemon=True).start()

def run_chat_background(username: str, user_message: str, priority: int = PRIORITY_NORMAL,
                         generation: int = None, platform: str = "Stream",
                         memory_key: str = None) -> None:
    """Non-streaming (no client to show tokens to) chat pipeline, used by
    Twitch/YouTube/Kick — but still speaks sentence-by-sentence as the LLM
    generates, same as the direct-chat path, so the first bit of audio
    doesn't wait on the whole reply. `generation` is the conversation
    generation this job started under — if a direct/mic message bumps it
    while the LLM is still streaming, generation stops early and nothing
    gets spoken or remembered. `platform` (e.g. "Twitch", "YouTube", "Kick")
    is only used to label the chat history entry and the console log.
    `memory_key`, if given, is the unique per-person identity used for
    memory storage — separate from `username` (the display name) because a
    display name alone isn't guaranteed unique, especially on YouTube.
    Defaults to `username` when not given."""
    key = memory_key or username
    messages = build_messages(username, user_message, memory_key=key)
    set_state(is_talking=True)
    full = ""
    unspoken = ""
    interrupted = False
    tagbuf = _new_tag_buffer()
    try:
        for token in stream_reply(messages):
            if generation is not None and generation != current_generation():
                interrupted = True
                break
            emitted = _consume_leading_tag(tagbuf, token)
            if not emitted:
                continue
            full += emitted
            unspoken += emitted
            chunks, unspoken = _pop_ready_chunks(unspoken)
            for chunk in chunks:
                tts_speak(chunk, priority=priority, generation=generation, emotion=tagbuf["emotion"])
        if not interrupted:
            leftover = _flush_leading_tag(tagbuf)
            if leftover:
                full += leftover
                unspoken += leftover
    except requests.exceptions.ConnectionError:
        set_state(is_talking=False)
        return
    set_state(is_talking=False)
    if interrupted:
        return
    full = full.strip()
    if not full or full.startswith("[ERROR]"):
        return
    char_name = get_active_character()["character_name"]
    log_chat(platform, f"{username}: {user_message}")
    log_chat(char_name, full)
    chat_history.append({"role": "user", "content": f"[{platform}] {username}: {user_message}"})
    chat_history.append({"role": "assistant", "content": full})
    remainder = unspoken.strip()
    if remainder:
        tts_speak(remainder, priority=priority, generation=generation, emotion=tagbuf["emotion"])
    threading.Thread(target=memory.update, args=(char_name, key, user_message, full), daemon=True).start()

# ══════════════════════════════════════════════════════════════
# STREAM CHAT — Twitch, YouTube, Kick: read-only listening, replies
# via voice only. Any combination can be turned on at once.
# ══════════════════════════════════════════════════════════════

# ── Shared reply queue ──
# Messages from ANY connected platform that warrant a reply land in one
# shared queue (capped at 10, dropping the oldest pending one once full)
# and are worked one at a time by a single worker, so a busy chat (or three
# busy chats at once) can't fire off a pile of concurrent LLM calls.
# Direct/mic messages always take priority for speaking (see
# interrupt_stream above) — this queue only governs the order stream-chat
# replies get *generated* in.
STREAM_QUEUE_MAXLEN = 10
_stream_queue: "deque" = deque(maxlen=STREAM_QUEUE_MAXLEN)
_stream_queue_lock = threading.Lock()
_stream_queue_event = threading.Event()

def _enqueue_stream_message(platform: str, username: str, memory_key: str, message: str) -> None:
    with _stream_queue_lock:
        dropped = len(_stream_queue) == _stream_queue.maxlen
        _stream_queue.append((platform, username, memory_key, message))
    if dropped:
        log_warn("Stream reply queue full (10) — dropped the oldest pending message")
    _stream_queue_event.set()

def _stream_worker():
    while True:
        _stream_queue_event.wait()
        with _stream_queue_lock:
            if not _stream_queue:
                _stream_queue_event.clear()
                continue
            platform, username, memory_key, message = _stream_queue.popleft()
            if not _stream_queue:
                _stream_queue_event.clear()
        run_chat_background(username, message, priority=PRIORITY_NORMAL,
                             generation=current_generation(), platform=platform,
                             memory_key=memory_key)

threading.Thread(target=_stream_worker, daemon=True, name="stream-worker").start()

def _stream_should_reply(message: str, ai_names) -> bool:
    lowered = message.lower()
    if any(name.lower() in lowered for name in ai_names if name):
        return True
    if message.strip().endswith("?"):
        return True
    return False

def sync_stream_platforms() -> None:
    """Starts/stops each platform's listener to match its current enabled
    flag. Call this any time config is loaded or changed."""
    start_twitch()  if config.get("twitch_enabled")  else stop_twitch()
    start_youtube() if config.get("youtube_enabled") else stop_youtube()
    start_kick()    if config.get("kick_enabled")    else stop_kick()

# ── Twitch — anonymous read-only IRC, no token needed ──

_twitch_thread = None
_twitch_running = False
_twitch_connected = False   # True only while the socket is actually up right now

def start_twitch():
    global _twitch_thread, _twitch_running
    if not config.get("twitch_enabled"):
        return
    channel = config.get("twitch_channel", "").strip()
    if not channel:
        log_warn("Twitch: set twitch_channel in Settings"); return
    if _twitch_thread and _twitch_thread.is_alive():
        return
    _twitch_running = True
    _twitch_thread = threading.Thread(target=_twitch_loop, daemon=True, name="twitch")
    _twitch_thread.start()
    log_ok(f"Twitch IRC -> #{channel}")

def stop_twitch():
    global _twitch_running, _twitch_connected
    _twitch_running = False
    _twitch_connected = False

def _twitch_loop():
    global _twitch_connected
    channel = config.get("twitch_channel", "").lower()
    while _twitch_running and config.get("twitch_enabled"):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(300)
            s.connect(("irc.chat.twitch.tv", 6667))
            nick = f"justinfan{random.randint(10000, 99999)}"
            s.sendall(f"PASS SCHMOOPIIE\r\nNICK {nick}\r\nJOIN #{channel}\r\n".encode())
            buf = ""
            _twitch_connected = True
            log_ok(f"Twitch chat connected -> #{channel}")
            while _twitch_running and config.get("twitch_enabled"):
                data = s.recv(2048).decode("utf-8", errors="ignore")
                if not data:
                    break
                buf += data
                while "\r\n" in buf:
                    line, buf = buf.split("\r\n", 1)
                    if line.startswith("PING"):
                        s.sendall(b"PONG :tmi.twitch.tv\r\n"); continue
                    m = re.match(r"^(?:@\S+ )?:(\w+)!\w+@\S+ PRIVMSG #\S+ :(.+)$", line)
                    if not m:
                        continue
                    username, message = m.group(1).lower(), m.group(2).strip()
                    ai_names = config.get("ai_names", ["mey"])
                    if username in (n.lower() for n in ai_names if n):
                        continue
                    if _stream_should_reply(message, ai_names):
                        log_chat("TWITCH", f"{username}: {message}")
                        # Twitch login names are already globally unique, but
                        # prefixed anyway so a Twitch "sam" can never collide
                        # with a same-named viewer on another platform.
                        _enqueue_stream_message("Twitch", username, f"twitch:{username}", message)
            s.close()
        except Exception as e:
            if _twitch_running:
                log_warn(f"Twitch disconnected: {e} — retrying in 10s")
                _twitch_connected = False
                time.sleep(10)
        finally:
            _twitch_connected = False

# ── YouTube — polls the YouTube Data API v3 live chat endpoint ──
# Needs a free API key from Google Cloud Console (enable "YouTube Data API
# v3"). Either point it at a specific live video ID, or at your channel ID
# to auto-detect whichever video is currently live.

_youtube_thread = None
_youtube_running = False
_youtube_connected = False   # True only while we have a live chat and polling is succeeding

def start_youtube():
    global _youtube_thread, _youtube_running
    if not config.get("youtube_enabled"):
        return
    if not config.get("youtube_api_key", "").strip():
        log_warn("YouTube: set youtube_api_key in Settings"); return
    if not config.get("youtube_video_id", "").strip() and not config.get("youtube_channel_id", "").strip():
        log_warn("YouTube: set a video ID or channel ID in Settings"); return
    if _youtube_thread and _youtube_thread.is_alive():
        return
    _youtube_running = True
    _youtube_thread = threading.Thread(target=_youtube_loop, daemon=True, name="youtube")
    _youtube_thread.start()
    log_ok("YouTube: looking for your livestream...")

def stop_youtube():
    global _youtube_running, _youtube_connected
    _youtube_running = False
    _youtube_connected = False

def _youtube_resolve_live_chat_id(api_key: str) -> str | None:
    """Video ID takes priority if both are set. Falls back to searching the
    channel for whatever's currently live."""
    video_id = config.get("youtube_video_id", "").strip()
    channel_id = config.get("youtube_channel_id", "").strip()
    try:
        if not video_id and channel_id:
            r = requests.get("https://www.googleapis.com/youtube/v3/search", params={
                "part": "snippet", "channelId": channel_id, "eventType": "live",
                "type": "video", "key": api_key,
            }, timeout=10)
            items = r.json().get("items", [])
            if not items:
                return None
            video_id = items[0]["id"]["videoId"]
        if not video_id:
            return None
        r = requests.get("https://www.googleapis.com/youtube/v3/videos", params={
            "part": "liveStreamingDetails", "id": video_id, "key": api_key,
        }, timeout=10)
        items = r.json().get("items", [])
        if not items:
            return None
        return items[0].get("liveStreamingDetails", {}).get("activeLiveChatId")
    except Exception as e:
        log_warn(f"YouTube: couldn't look up the livestream ({e})")
        return None

def _youtube_loop():
    global _youtube_connected
    api_key = config.get("youtube_api_key", "").strip()
    live_chat_id = None
    page_token = None
    while _youtube_running and config.get("youtube_enabled"):
        try:
            if not live_chat_id:
                live_chat_id = _youtube_resolve_live_chat_id(api_key)
                if not live_chat_id:
                    _youtube_connected = False
                    log_warn("YouTube: no active livestream found — retrying in 60s")
                    time.sleep(60)
                    continue
                page_token = None
                log_ok("YouTube live chat connected")
            params = {"liveChatId": live_chat_id, "part": "snippet,authorDetails", "key": api_key}
            if page_token:
                params["pageToken"] = page_token
            r = requests.get("https://www.googleapis.com/youtube/v3/liveChat/messages",
                              params=params, timeout=15)
            if r.status_code != 200:
                _youtube_connected = False
                log_warn(f"YouTube: API returned {r.status_code} — retrying in 30s")
                live_chat_id = None
                time.sleep(30)
                continue
            _youtube_connected = True
            data = r.json()
            page_token = data.get("nextPageToken")
            ai_names = config.get("ai_names", ["mey"])
            for item in data.get("items", []):
                author = item.get("authorDetails", {})
                username = author.get("displayName", "viewer")
                # Display names aren't unique on YouTube — two different
                # viewers can both be "Alex". channelId is the real unique
                # identity, so that's what memory is keyed by; the display
                # name is only used for what's shown/spoken.
                channel_id = author.get("channelId", "")
                memory_key = f"youtube:{channel_id}" if channel_id else f"youtube:{username.lower()}"
                message = item.get("snippet", {}).get("displayMessage", "")
                if not message or username.lower() in (n.lower() for n in ai_names if n):
                    continue
                if _stream_should_reply(message, ai_names):
                    log_chat("YOUTUBE", f"{username}: {message}")
                    _enqueue_stream_message("YouTube", username, memory_key, message)
            interval = max(data.get("pollingIntervalMillis", 5000), 5000) / 1000
            time.sleep(interval)
        except Exception as e:
            _youtube_connected = False
            if _youtube_running:
                log_warn(f"YouTube chat error: {e} — retrying in 30s")
                live_chat_id = None
                time.sleep(30)

# ── Kick — public chatroom feed, no login needed ──
# Uses Kick's public site API to find the chatroom, then its public Pusher
# websocket feed (the same one kick.com's own chat widget uses). This is
# unofficial and could break if Kick changes their site.

KICK_PUSHER_URL = "wss://ws-us2.pusher.com/app/32cbd69e4b950bf97679?protocol=7&client=js&version=7.6.0&flash=false"

_kick_thread = None
_kick_running = False
_kick_connected = False   # True only while the Pusher socket is actually up right now

def start_kick():
    global _kick_thread, _kick_running
    if not config.get("kick_enabled"):
        return
    if not _WS_CLIENT_AVAILABLE:
        log_warn("Kick: websocket-client isn't installed — run INSTALL.bat again"); return
    channel = config.get("kick_channel", "").strip()
    if not channel:
        log_warn("Kick: set kick_channel in Settings"); return
    if _kick_thread and _kick_thread.is_alive():
        return
    _kick_running = True
    _kick_thread = threading.Thread(target=_kick_loop, daemon=True, name="kick")
    _kick_thread.start()
    log_ok(f"Kick chat -> {channel}")

def stop_kick():
    global _kick_running, _kick_connected
    _kick_running = False
    _kick_connected = False

def _kick_lookup_chatroom_id(channel: str) -> int | None:
    try:
        r = requests.get(f"https://kick.com/api/v2/channels/{channel}", timeout=10,
                          headers={"User-Agent": "Mozilla/5.0"})
        if r.status_code != 200:
            return None
        return r.json().get("chatroom", {}).get("id")
    except Exception:
        return None

def _kick_loop():
    global _kick_connected
    channel = config.get("kick_channel", "").strip().lower()
    while _kick_running and config.get("kick_enabled"):
        room_id = _kick_lookup_chatroom_id(channel)
        if not room_id:
            _kick_connected = False
            log_warn(f"Kick: couldn't find channel '{channel}' — retrying in 30s")
            time.sleep(30)
            continue
        try:
            ws = _ws_client.create_connection(KICK_PUSHER_URL, timeout=300)
            ws.send(json.dumps({"event": "pusher:subscribe", "data": {"channel": f"chatrooms.{room_id}.v2"}}))
            _kick_connected = True
            log_ok(f"Kick chat connected -> {channel}")
            while _kick_running and config.get("kick_enabled"):
                raw = ws.recv()
                if not raw:
                    break
                try:
                    msg = json.loads(raw)
                except Exception:
                    continue
                if msg.get("event") != "App\\Events\\ChatMessageEvent":
                    continue
                try:
                    payload = json.loads(msg.get("data", "{}"))
                except Exception:
                    continue
                sender = payload.get("sender", {})
                username = sender.get("username", "viewer")
                message = payload.get("content", "")
                # Kick's numeric sender id is the true unique identity — the
                # username is normally unique too, but the id is a harder
                # guarantee and costs nothing to prefer when it's present.
                sender_id = sender.get("id")
                memory_key = f"kick:{sender_id}" if sender_id is not None else f"kick:{username.lower()}"
                ai_names = config.get("ai_names", ["mey"])
                if not message or username.lower() in (n.lower() for n in ai_names if n):
                    continue
                if _stream_should_reply(message, ai_names):
                    log_chat("KICK", f"{username}: {message}")
                    _enqueue_stream_message("Kick", username, memory_key, message)
            ws.close()
        except Exception as e:
            if _kick_running:
                log_warn(f"Kick disconnected: {e} — retrying in 10s")
                time.sleep(10)
        finally:
            _kick_connected = False

# ══════════════════════════════════════════════════════════════
# ROUTES
# ══════════════════════════════════════════════════════════════

@app.route("/")
def index():
    log_info("Control panel opened")
    return render_template("control.html")

@app.route("/api/chat", methods=["POST"])
def chat():
    user_msg = (request.json or {}).get("message", "").strip()
    if not user_msg:
        return jsonify({"error": "Empty message"}), 400
    # streamer_name (e.g. "Senpai") is what the character calls you in the
    # prompt; streamer_id is the separate, stable key your facts are filed
    # under in memory.json — kept apart so renaming one doesn't affect the
    # other.
    display_name = get_active_character().get("streamer_name") or "you"
    memory_key = config.get("streamer_id", "streamer")
    def generate():
        for token in run_chat_stream(display_name, user_msg, memory_key=memory_key):
            yield f"data: {json.dumps({'token': token})}\n\n"
        yield f"data: {json.dumps({'done': True})}\n\n"
    return Response(stream_with_context(generate()), mimetype="text/event-stream")

@app.route("/api/state")
def state_stream():
    q = queue.Queue()
    state_subscribers.append(q)
    def generate():
        yield f"data: {json.dumps(character_state)}\n\n"
        try:
            while True:
                try:
                    yield f"data: {q.get(timeout=30)}\n\n"
                except queue.Empty:
                    yield f"data: {json.dumps({'ping': True})}\n\n"
        finally:
            if q in state_subscribers:
                state_subscribers.remove(q)
    return Response(stream_with_context(generate()), mimetype="text/event-stream")

@app.route("/api/tts_audio")
def tts_audio():
    """Browser polls this for the next queued Piper/GPT-SoVITS clip, in order."""
    try:
        data = _tts_ready.get_nowait()
        return Response(data, mimetype="audio/wav", headers={"Cache-Control": "no-cache"})
    except queue.Empty:
        return Response(status=204)

_TTS_OVERRIDE_KEYS = {
    "piper_exe", "piper_model",
    "gptsovits_url", "gptsovits_ref_audio", "gptsovits_ref_text", "gptsovits_lang",
    "browser_voice_name", "browser_voice_lang",
}

REF_AUDIO_DIR = os.path.join(BASE_DIR, "ref_audio_uploads")

@app.route("/api/upload/reference_audio", methods=["POST"])
def upload_reference_audio():
    """Saves an uploaded .wav reference clip for GPT-SoVITS locally and
    returns its path, so the Reference audio field can be filled by
    dragging/dropping or browsing for a file instead of typing a full path
    by hand. Browsers never expose a picked/dropped file's real path on
    disk (a security restriction, not something this app can work around),
    so the file's actual bytes are uploaded and saved here instead — the
    returned path points at that saved copy."""
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify({"error": "No file received"}), 400
    if not f.filename.lower().endswith(".wav"):
        return jsonify({"error": "Please choose a .wav file"}), 400
    os.makedirs(REF_AUDIO_DIR, exist_ok=True)
    safe_name = secure_filename(f.filename) or "reference.wav"
    path = os.path.join(REF_AUDIO_DIR, safe_name)
    if os.path.exists(path):
        stem, ext = os.path.splitext(safe_name)
        path = os.path.join(REF_AUDIO_DIR, f"{stem}_{int(time.time())}{ext}")
    try:
        f.save(path)
    except Exception as e:
        return jsonify({"error": f"Couldn't save the file: {e}"}), 500
    log_ok(f"Saved reference audio -> {path}")
    return jsonify({"status": "ok", "path": path})

VOICE_MODELS_DIR = os.path.join(BASE_DIR, "voice_models")

@app.route("/api/upload/voice_model", methods=["POST"])
def upload_voice_model():
    """Saves an uploaded Piper .onnx voice model locally (same drag-drop-or-
    browse pattern as reference_audio above) and returns its path. Piper
    also expects a same-named '<model>.onnx.json' config file sitting next
    to the .onnx — if the user dropped both at once (the common case, since
    downloaded Piper voices come as a pair), the companion file is saved
    alongside it under a matching name so Piper can find it automatically.
    If only the .onnx was provided, it's saved alone and the UI warns that
    the .json config also needs to be placed next to it by hand."""
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify({"error": "No file received"}), 400
    if not f.filename.lower().endswith(".onnx"):
        return jsonify({"error": "Please choose a .onnx voice model file"}), 400
    os.makedirs(VOICE_MODELS_DIR, exist_ok=True)
    safe_name = secure_filename(f.filename) or "voice.onnx"
    path = os.path.join(VOICE_MODELS_DIR, safe_name)
    if os.path.exists(path):
        stem, ext = os.path.splitext(safe_name)
        safe_name = f"{stem}_{int(time.time())}{ext}"
        path = os.path.join(VOICE_MODELS_DIR, safe_name)
    try:
        f.save(path)
    except Exception as e:
        return jsonify({"error": f"Couldn't save the file: {e}"}), 500

    config_saved = False
    cf = request.files.get("config_file")
    if cf and cf.filename:
        config_path = path + ".json"  # must exactly match "<same name as .onnx>.json" for Piper to find it
        try:
            cf.save(config_path)
            config_saved = True
        except Exception as e:
            log_warn(f"Voice model saved but couldn't save its config file: {e}")

    log_ok(f"Saved voice model -> {path}" + (" (with config)" if config_saved else ""))
    return jsonify({"status": "ok", "path": path, "config_saved": config_saved})

@app.route("/api/tts/test", methods=["POST"])
def test_tts():
    """Speaks a sample line with the engine/fields currently showing in the
    Settings form — even if you haven't hit Save yet. Runs Piper/GPT-SoVITS
    generation synchronously (skips the normal priority queue) so the result
    comes straight back; the browser engine needs no server round-trip at all
    and is handled entirely client-side."""
    data = request.json or {}
    engine = data.get("engine")
    if not engine:
        return jsonify({"error": "No engine specified"}), 400
    text = (data.get("text") or "").strip() or "This is a test of your voice settings, baka!"

    if engine not in ("piper", "gptsovits"):
        return jsonify({"error": f'Unknown engine "{engine}"'}), 400

    overrides = {k: v for k, v in data.items() if k in _TTS_OVERRIDE_KEYS and v not in (None, "")}
    snapshot = {k: config.get(k) for k in overrides}
    config.update(overrides)
    try:
        before = _tts_ready.qsize()
        if engine == "piper":
            _piper_speak(text)
        else:
            _sovits_speak(text)
        if _tts_ready.qsize() <= before:
            return jsonify({"error": "Generation failed — check the server console for details"}), 500
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        config.update(snapshot)
    return jsonify({"status": "ok", "engine": engine})

@app.route("/api/config", methods=["GET"])
def get_config():
    return jsonify(get_config_view())

@app.route("/api/config", methods=["POST"])
def update_config():
    global memory, vts, expr, vts_ok
    old_vts = (config["vts_host"], config["vts_port"], config["vts_enabled"])
    old_mem = (config["memory_file"], config["max_facts"], config.get("memory_decay_days", 30))

    payload = dict(request.json or {})
    ai_names_update = payload.pop("ai_names", None)  # per-character, not a plain persona field — handled separately below

    persona_update = {k: v for k, v in payload.items() if k in PERSONA_KEYS}
    other_update   = {k: v for k, v in payload.items() if k not in PERSONA_KEYS}

    active = characters_store["active"]
    char = characters_store["characters"][active]
    chars_changed = False

    if persona_update:
        if char.get("protected"):
            persona_update = {}  # built-in characters can't be edited — silently ignore persona changes
        else:
            char.update(persona_update)
            # Safety rules can never be edited away via this route either.
            char["rules"] = BASE_SAFETY_RULES + [r for r in char.get("rules", []) if r not in BASE_SAFETY_RULES]
            chars_changed = True

    if ai_names_update is not None:
        # Trigger words are a per-character setting, like voice_override — editable
        # even for a protected/built-in character, since it's not a persona field.
        cleaned = [str(w).strip() for w in ai_names_update if str(w).strip()]
        char["ai_names"] = cleaned
        other_update["ai_names"] = cleaned  # keep config's runtime copy in sync for the stream listeners
        chars_changed = True

    if chars_changed:
        save_characters(characters_store)

    config.update(other_update)
    save_config(config)

    new_mem = (config["memory_file"], config["max_facts"], config.get("memory_decay_days", 30))
    if new_mem != old_mem:
        memory = MemoryManager(memory_file=config["memory_file"], max_facts=config["max_facts"],
                                ollama_url=config["ollama_url"], ollama_model=config["ollama_model"],
                                decay_half_life_days=config.get("memory_decay_days", 30))
        memory.trim_to_max()

    new_vts = (config["vts_host"], config["vts_port"], config["vts_enabled"])
    if new_vts != old_vts:
        try: vts.disconnect()
        except Exception: pass
        vts = VTubeStudio(host=config["vts_host"], port=config["vts_port"])
        expr = ExpressionController(vts, idle_timeout=config.get("expression_idle_seconds", 8))
        vts_ok = False
        if config["vts_enabled"]:
            threading.Thread(target=_connect_vts, daemon=True).start()

    sync_stream_platforms()

    log_ok("Config saved")
    return jsonify({"status": "saved"})

# ══════════════════════════════════════════════════════════════
# BACKUP — export/import config.json + characters.json + memory.json
# as one bundle, so you can move a setup between machines or undo
# a bad hand-edit.
# ══════════════════════════════════════════════════════════════

SECRET_CONFIG_KEYS = {"openai_api_key", "gemini_api_key", "youtube_api_key"}
BACKUPS_DIR = "backups"

@app.route("/api/backup/export")
def backup_export():
    # API keys are never included in a backup file, no matter what — there's
    # no option to opt back into that.
    cfg = dict(config)
    for k in SECRET_CONFIG_KEYS:
        if cfg.get(k):
            cfg[k] = ""

    mem_data = {}
    mem_path = config.get("memory_file", "memory.json")
    if os.path.exists(mem_path):
        try:
            with open(mem_path, encoding="utf-8") as f:
                mem_data = json.load(f)
        except Exception as e:
            log_err(f"Backup: couldn't read {mem_path}: {e}")

    bundle = {
        "app": "astro_v",
        "backup_version": 1,
        "exported_at": datetime.now().isoformat(timespec="seconds"),
        "redacted": True,
        "config": cfg,
        "characters": characters_store,
        "memory": mem_data,
    }
    fname = f"astro_v_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    return Response(
        json.dumps(bundle, indent=2),
        mimetype="application/json",
        headers={"Content-Disposition": f'attachment; filename="{fname}"'},
    )

@app.route("/api/backup/import", methods=["POST"])
def backup_import():
    """Restores config/characters/memory from an exported bundle. The
    currently active files are copied into backups/ first, timestamped,
    so a bad import can be undone by hand."""
    global config, characters_store, memory, vts, expr, vts_ok

    bundle = request.json or {}
    # "tsundere_voice_chat" is accepted too — that's what backups exported
    # before the project was renamed to Astro V used as their app id.
    if bundle.get("app") not in ("astro_v", "tsundere_voice_chat") or "config" not in bundle:
        return jsonify({"error": "This doesn't look like an Astro V backup file"}), 400

    os.makedirs(BACKUPS_DIR, exist_ok=True)
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    for path in (CONFIG_FILE, CHARACTERS_FILE, config.get("memory_file", "memory.json")):
        if os.path.exists(path):
            try:
                shutil.copy2(path, os.path.join(BACKUPS_DIR, f"{os.path.basename(path)}.{stamp}.bak"))
            except Exception as e:
                log_err(f"Backup: couldn't snapshot {path}: {e}")

    new_config = dict(DEFAULT_CONFIG)
    new_config.update(bundle.get("config") or {})
    # Never blow away real keys with a redacted (blank) backup.
    for k in SECRET_CONFIG_KEYS:
        if not new_config.get(k) and config.get(k):
            new_config[k] = config[k]
    # An older backup (pre-v0.9) won't have moods at all — seed them rather
    # than leaving the DEFAULT_CONFIG placeholder (None) in place.
    if not new_config.get("moods"):
        new_config["moods"] = copy.deepcopy(DEFAULT_MOODS)
    save_config(new_config)
    config = new_config

    imported_chars = bundle.get("characters")
    if isinstance(imported_chars, dict) and imported_chars.get("characters"):
        save_characters(imported_chars)
        characters_store = imported_chars

    mem_data = bundle.get("memory")
    if isinstance(mem_data, dict):
        try:
            with open(config.get("memory_file", "memory.json"), "w", encoding="utf-8") as f:
                json.dump(mem_data, f, indent=2)
        except Exception as e:
            log_err(f"Backup: couldn't write memory file: {e}")

    memory = MemoryManager(memory_file=config["memory_file"], max_facts=config["max_facts"],
                            ollama_url=config["ollama_url"], ollama_model=config["ollama_model"],
                            decay_half_life_days=config.get("memory_decay_days", 30))
    try: vts.disconnect()
    except Exception: pass
    vts = VTubeStudio(host=config["vts_host"], port=config["vts_port"])
    expr = ExpressionController(vts, idle_timeout=config.get("expression_idle_seconds", 8))
    vts_ok = False
    if config.get("vts_enabled"):
        threading.Thread(target=_connect_vts, daemon=True).start()
    sync_stream_platforms()
    load_moods(config["moods"])

    log_ok("Backup imported")
    return jsonify({"status": "restored", "config": get_config_view()})

@app.route("/api/clear_history", methods=["POST"])
def clear_history():
    global chat_history
    chat_history = []
    log_info("Chat history cleared")
    return jsonify({"status": "cleared"})

@app.route("/api/memory", methods=["GET"])
def get_memory():
    """Memory as seen by the currently active character — each character
    remembers you (and any viewers) separately."""
    char_name = get_active_character()["character_name"]
    username = config.get("streamer_id", "streamer")
    return jsonify({
        "character": char_name,
        "facts": memory.get_facts(char_name, username),
        # Same facts, but with relevance score / reinforcement count / age —
        # ordered strongest-first, for the "fresh vs. fading" view in the panel.
        "facts_detailed": memory.get_facts_detailed(char_name, username),
    })

@app.route("/api/memory", methods=["DELETE"])
def clear_memory():
    """Wipes what the CURRENTLY ACTIVE character remembers about you — other
    characters' memory of you is untouched."""
    char_name = get_active_character()["character_name"]
    username = config.get("streamer_id", "streamer")
    memory.clear_user(char_name, username)
    log_info(f"{char_name}'s memory of {username} cleared")
    return jsonify({"status": "cleared"})

@app.route("/api/memory/viewers", methods=["DELETE"])
def clear_viewer_memory():
    """Wipes what the currently active character remembers about everyone
    EXCEPT you (e.g. Twitch chatters it has learned facts about)."""
    char_name = get_active_character()["character_name"]
    username = config.get("streamer_id", "streamer")
    all_users = memory.all_users(char_name)
    cleared = 0
    for name in list(all_users.keys()):
        if name == username:
            continue
        memory.clear_user(char_name, name)
        cleared += 1
    log_info(f"Cleared {char_name}'s memory of {cleared} viewer(s)")
    return jsonify({"status": "cleared", "count": cleared})

@app.route("/api/memory/user", methods=["DELETE"])
def clear_named_user_memory():
    """Wipes what the currently active character remembers about one
    specific username (e.g. a single Twitch viewer, or yourself by entering
    your own streamer_id)."""
    char_name = get_active_character()["character_name"]
    name = (request.json or {}).get("name", "").strip()
    if not name:
        return jsonify({"error": "Name is required"}), 400
    if name not in memory.all_users(char_name):
        return jsonify({"error": f'No memory found for "{name}"'}), 404
    memory.clear_user(char_name, name)
    log_info(f"Cleared {char_name}'s memory of user: {name}")
    return jsonify({"status": "cleared", "name": name})

@app.route("/api/memory/characters", methods=["GET"])
def list_memory_characters():
    """Every character that has ANY memory stored — including characters
    that aren't currently active — so the panel can offer to wipe a
    character's memory without having to switch to it first."""
    with_memory = set(memory.all_characters())
    all_names = [c["name"] for c in get_config_view()["character_list"]]
    return jsonify({
        "characters": [
            {"name": name, "has_memory": name in with_memory,
             "user_count": len(memory.all_users(name))}
            for name in all_names
        ]
    })

@app.route("/api/memory/character", methods=["DELETE"])
def clear_character_memory():
    """Wipes EVERYTHING one named character remembers — every user it has
    ever talked to. Other characters' memories are untouched."""
    name = (request.json or {}).get("name", "").strip()
    if not name:
        return jsonify({"error": "Character name is required"}), 400
    count = memory.clear_character(name)
    if count == 0:
        return jsonify({"error": f'"{name}" has no memory to clear'}), 404
    log_info(f"Cleared all memory for character '{name}' ({count} user(s))")
    return jsonify({"status": "cleared", "name": name, "user_count": count})

@app.route("/api/memory/fact", methods=["DELETE"])
def delete_memory_fact():
    char_name = get_active_character()["character_name"]
    username = config.get("streamer_id", "streamer")
    fact = (request.json or {}).get("fact", "")
    ok = memory.delete_fact(char_name, username, fact)
    if not ok:
        return jsonify({"error": "Fact not found"}), 404
    log_info(f"Deleted a memory fact for {username}")
    return jsonify({"status": "deleted", "facts": memory.get_facts(char_name, username)})

@app.route("/api/memory/all", methods=["DELETE"])
def clear_all_memory():
    """Wipes EVERYTHING, every character's memory of every person — the
    nuclear option. Wiping one character (see /api/memory/character) is
    usually what you want instead."""
    memory.clear_all()
    log_info("Wiped ALL memory — every character, every person")
    return jsonify({"status": "cleared"})

@app.route("/api/vts/expressions", methods=["GET"])
def list_vts_expressions():
    """Lists the expression files actually loaded on the current VTube Studio
    model, straight from VTS itself — so you can see the real filenames and
    match them up against each mood's expression file in Settings > Expressions,
    instead of guessing."""
    if not config.get("vts_enabled"):
        return jsonify({"error": "VTube Studio integration is disabled in Settings"}), 400
    if not vts.is_ready():
        return jsonify({"error": "Not connected to VTube Studio"}), 400
    try:
        expressions = vts.get_expressions()
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    return jsonify({
        "expressions": [
            {"name": e.get("name", ""), "file": e.get("file", ""), "active": e.get("active", False)}
            for e in expressions
        ]
    })

@app.route("/api/vts/reconnect", methods=["POST"])
def reconnect_vts():
    """Manually reconnect to VTube Studio after a disconnect (VTS was closed,
    network hiccup, etc). VTS no longer auto-retries on its own, so this is
    what the Reconnect button in Settings > VTube Studio calls. Blocks for
    the duration of the handshake (a few seconds, up to ~10s if VTS doesn't
    respond) and reports whether it actually succeeded."""
    global vts_ok
    if not config.get("vts_enabled"):
        return jsonify({"error": "VTube Studio integration is disabled in Settings"}), 400
    if vts.is_ready():
        return jsonify({"status": "already_connected", "vts_ready": True})
    if not _vts_reconnect_lock.acquire(blocking=False):
        return jsonify({"error": "A reconnect attempt is already in progress"}), 409
    try:
        vts_ok = vts.connect()
    finally:
        _vts_reconnect_lock.release()
    if vts_ok:
        log_ok("VTube Studio reconnected")
        return jsonify({"status": "connected", "vts_ready": True})
    return jsonify({
        "status": "failed",
        "vts_ready": False,
        "error": "Could not connect to VTube Studio — make sure it's open and the API is enabled",
    }), 502

@app.route("/api/vts/hotkeys", methods=["GET"])
def list_vts_hotkeys():
    """Lists the hotkeys set up on the current VTube Studio model, straight
    from VTS itself, so they can be triggered manually from the panel."""
    if not config.get("vts_enabled"):
        return jsonify({"error": "VTube Studio integration is disabled in Settings"}), 400
    if not vts.is_ready():
        return jsonify({"error": "Not connected to VTube Studio"}), 400
    try:
        hotkeys = vts.get_hotkeys()
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    return jsonify({
        "hotkeys": [
            {"name": h.get("name", ""), "hotkeyID": h.get("hotkeyID", ""), "type": h.get("type", "")}
            for h in hotkeys
        ]
    })

@app.route("/api/vts/hotkeys/trigger", methods=["POST"])
def trigger_vts_hotkey():
    """Fires one VTube Studio hotkey immediately, by the id returned from
    /api/vts/hotkeys."""
    if not config.get("vts_enabled"):
        return jsonify({"error": "VTube Studio integration is disabled in Settings"}), 400
    if not vts.is_ready():
        return jsonify({"error": "Not connected to VTube Studio"}), 400
    hotkey_id = (request.json or {}).get("hotkeyID", "").strip()
    if not hotkey_id:
        return jsonify({"error": "hotkeyID is required"}), 400
    try:
        ok = vts.trigger_hotkey(hotkey_id)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    if not ok:
        return jsonify({"error": "VTube Studio didn't confirm the hotkey fired"}), 500
    return jsonify({"status": "triggered", "hotkeyID": hotkey_id})

@app.route("/api/expression/test", methods=["POST"])
def test_expression():
    """Fires one mood immediately (bypasses keyword detection), and drives the
    live VTube Studio model if it's connected."""
    emotion = (request.json or {}).get("emotion", "")
    if not is_known_emotion(emotion):
        return jsonify({"error": f'Unknown emotion "{emotion}"'}), 400

    ok, err = expr.preview(emotion)
    set_state(emotion=emotion)

    file = get_expression_file(emotion)
    return jsonify({
        "status": "ok",
        "emotion": emotion,
        "emoji": get_emoji(emotion),
        "file": file,
        "vts_enabled": config.get("vts_enabled", False),
        "vts_ready": vts.is_ready(),
        "vts_fired": ok,
        "vts_error": err,
    })

MOOD_KEY_RE = re.compile(r"^[a-z][a-z0-9_]{0,31}$")

@app.route("/api/moods", methods=["GET"])
def list_moods():
    """All moods currently in the registry — emoji, VTS expression filename,
    and the keywords that trigger each one automatically."""
    return jsonify({"moods": get_moods()})

@app.route("/api/moods", methods=["POST"])
def create_mood():
    """Adds a brand new mood. Once added it's immediately usable — the LLM
    can pick it via [emotion:x] tags, keyword detection picks it up, and it
    shows up in the Expressions tester."""
    data = request.json or {}
    key = (data.get("key") or "").strip().lower()
    if not key:
        return jsonify({"error": "A mood key is required"}), 400
    if not MOOD_KEY_RE.match(key):
        return jsonify({"error": "Mood keys must be lowercase letters, numbers, or underscores, starting with a letter (max 32 chars)"}), 400
    moods = dict(config.get("moods") or {})
    if key in moods:
        return jsonify({"error": f'A mood called "{key}" already exists'}), 409
    moods[key] = {
        "emoji": (data.get("emoji") or "🙂").strip() or "🙂",
        "file": (data.get("file") or "").strip() or None,
        "keywords": [kw.strip() for kw in (data.get("keywords") or []) if kw.strip()],
    }
    config["moods"] = moods
    save_config(config)
    load_moods(moods)
    log_ok(f"Added mood: {key}")
    return jsonify({"status": "created", "key": key, "moods": get_moods()})

@app.route("/api/moods/<key>", methods=["PUT"])
def update_mood(key):
    """Edits an existing mood's emoji, VTS expression filename, and/or
    trigger keywords. Use this to point a mood at your model's actual
    exported filename, e.g. "happy.exp3.json"."""
    moods = dict(config.get("moods") or {})
    if key not in moods:
        return jsonify({"error": f'No mood called "{key}"'}), 404
    data = request.json or {}
    current = moods[key]
    moods[key] = {
        "emoji": (data.get("emoji", current.get("emoji")) or "🙂").strip() or "🙂",
        "file": (data.get("file", current.get("file")) or "").strip() or None,
        "keywords": [kw.strip() for kw in (data.get("keywords", current.get("keywords", []))) if kw.strip()],
    }
    config["moods"] = moods
    save_config(config)
    load_moods(moods)
    log_ok(f"Updated mood: {key}")
    return jsonify({"status": "updated", "key": key, "moods": get_moods()})

@app.route("/api/moods/<key>", methods=["DELETE"])
def delete_mood(key):
    """Removes a mood. "neutral" can't be deleted — it's the resting state
    everything falls back to."""
    if key == "neutral":
        return jsonify({"error": '"neutral" can\'t be deleted — it\'s the fallback mood'}), 400
    moods = dict(config.get("moods") or {})
    if key not in moods:
        return jsonify({"error": f'No mood called "{key}"'}), 404
    del moods[key]
    config["moods"] = moods
    save_config(config)
    load_moods(moods)
    log_ok(f"Deleted mood: {key}")
    return jsonify({"status": "deleted", "moods": get_moods()})

@app.route("/api/characters", methods=["GET"])
def list_characters():
    chars = characters_store.get("characters", {})
    return jsonify({
        "active": characters_store.get("active"),
        "characters": [
            {"name": name, "description": c.get("description", "")}
            for name, c in chars.items()
        ],
    })

@app.route("/api/characters/new", methods=["POST"])
def new_character():
    global chat_history
    answers = request.json or {}
    name = (answers.get("name") or "").strip()
    if not name:
        return jsonify({"error": "Character name is required"}), 400

    chars = characters_store["characters"]
    save_name = name
    n = 2
    while save_name in chars:          # avoid clobbering an existing character with the same name
        save_name = f"{name} ({n})"
        n += 1

    log_info(f"Generating new character: {save_name}...")
    character = generate_character_from_answers(answers)
    character["character_name"] = save_name if save_name != name else name
    character["ai_names"] = _default_ai_names_for(save_name, chars, config.get("ai_names", []))

    chars[save_name] = character
    characters_store["active"] = save_name
    save_characters(characters_store)

    config["ai_names"] = character["ai_names"]
    save_config(config)

    chat_history = []  # fresh conversation for the new character
    log_ok(f"Character created and activated: {save_name}")
    return jsonify(get_config_view())

@app.route("/api/characters/switch", methods=["POST"])
def switch_character():
    global chat_history
    name = (request.json or {}).get("name", "")
    chars = characters_store.get("characters", {})
    if name not in chars:
        return jsonify({"error": "No such character"}), 404

    char = chars[name]
    if not char.get("ai_names"):
        char["ai_names"] = _default_ai_names_for(name, chars, config.get("ai_names", []))

    characters_store["active"] = name
    save_characters(characters_store)

    config["ai_names"] = char["ai_names"]
    save_config(config)

    chat_history = []
    log_info(f"Switched to character: {name}")
    return jsonify(get_config_view())

@app.route("/api/characters/<name>/voice", methods=["POST"])
def set_character_voice(name):
    """Sets or clears a per-character voice override. Not gated by the
    'protected' persona lock — even built-in characters can have their own
    voice, since it's a TTS setting, not a persona edit."""
    chars = characters_store.get("characters", {})
    if name not in chars:
        return jsonify({"error": "No such character"}), 404

    payload = request.json or {}
    override = payload.get("voice_override")
    if override is not None:
        if not isinstance(override, dict):
            return jsonify({"error": "voice_override must be an object or null"}), 400
        engine = override.get("tts_engine")
        cleaned = {}
        if engine in ("browser", "piper", "gptsovits"):
            cleaned["tts_engine"] = engine
        for k in _TTS_OVERRIDE_KEYS:
            if override.get(k):
                cleaned[k] = override[k]
        override = cleaned or None

    chars[name]["voice_override"] = override
    save_characters(characters_store)
    log_info(f"Voice override {'set' if override else 'cleared'} for {name}")
    return jsonify({"status": "saved", "voice_override": override})

@app.route("/api/characters/<name>", methods=["DELETE"])
def delete_character(name):
    chars = characters_store.get("characters", {})
    if name not in chars:
        return jsonify({"error": "No such character"}), 404
    if chars[name].get("protected"):
        return jsonify({"error": "This is a built-in character and can't be deleted"}), 400
    if len(chars) <= 1:
        return jsonify({"error": "Can't delete your only character"}), 400
    del chars[name]
    if characters_store["active"] == name:
        characters_store["active"] = next(iter(chars))
    save_characters(characters_store)
    log_info(f"Deleted character: {name}")
    return jsonify(get_config_view())

_llm_status_cache = {"key": None, "checked_at": 0.0, "ok": False}
LLM_STATUS_CACHE_SECONDS = 20   # /api/status is polled every 4s by the UI;
                                 # this keeps us from hammering OpenAI/Gemini
                                 # with a real request on every single poll.

def _check_llm_ready(provider: str) -> bool:
    """Ollama gets a fresh live check every call (cheap, local). OpenAI/Gemini
    get an actual reachability check now (not just 'is a key typed in'),
    but only re-checked every LLM_STATUS_CACHE_SECONDS — a real network call
    on every 4s status poll would be wasteful and, for OpenAI, hits a paid
    API's rate limits for no reason."""
    if provider == "ollama":
        try:
            r = requests.get(f"{config['ollama_url']}/api/tags", timeout=3)
            return r.status_code == 200
        except Exception:
            return False

    if provider == "openai":
        api_key = config.get("openai_api_key", "").strip()
        cache_key = ("openai", api_key)
    elif provider == "gemini":
        api_key = config.get("gemini_api_key", "").strip()
        cache_key = ("gemini", api_key)
    else:
        return False

    if not api_key:
        return False

    now = time.time()
    if (_llm_status_cache["key"] == cache_key
            and now - _llm_status_cache["checked_at"] < LLM_STATUS_CACHE_SECONDS):
        return _llm_status_cache["ok"]

    ok = False
    try:
        if provider == "openai":
            r = requests.get("https://api.openai.com/v1/models",
                              headers={"Authorization": f"Bearer {api_key}"}, timeout=5)
            ok = r.status_code == 200
        else:  # gemini
            r = requests.get("https://generativelanguage.googleapis.com/v1beta/models",
                              params={"key": api_key}, timeout=5)
            ok = r.status_code == 200
    except Exception:
        ok = False

    _llm_status_cache.update(key=cache_key, checked_at=now, ok=ok)
    return ok

@app.route("/api/status", methods=["GET"])
def status():
    provider = config.get("llm_provider", "ollama")
    llm_ok = _check_llm_ready(provider)
    tts_settings = get_effective_tts_config()
    engine = tts_settings.get("tts_engine")  # None if the active character has no voice set up
    return jsonify({
        "llm_provider": provider,
        "llm_ready": llm_ok,
        "character_name": get_active_character().get("character_name"),
        "character_state": character_state,
        "history_length": len(chat_history),
        "tts_engine": engine,
        "piper_ready": engine == "piper" and bool(tts_settings.get("piper_model")) and os.path.exists(tts_settings.get("piper_model", "")),
        "sovits_ready": engine == "gptsovits" and bool(tts_settings.get("gptsovits_ref_audio")),
        "vts_enabled": config.get("vts_enabled", False),
        "vts_ready": vts.is_ready(),
        "twitch_enabled": config.get("twitch_enabled", False),
        "twitch_running": _twitch_connected,
        "youtube_enabled": config.get("youtube_enabled", False),
        "youtube_running": _youtube_connected,
        "kick_enabled": config.get("kick_enabled", False),
        "kick_running": _kick_connected,
        "stream_queue_len": len(_stream_queue),
    })

# ══════════════════════════════════════════════════════════════
# STARTUP
# ══════════════════════════════════════════════════════════════

def _connect_vts():
    global vts_ok
    vts_ok = vts.connect()
    if vts_ok:
        log_ok("VTube Studio connected")
    else:
        log_warn("VTube Studio not found — continuing without avatar control")

def check_ollama():
    try:
        r = requests.get(f"{config['ollama_url']}/api/tags", timeout=5)
        if r.status_code == 200:
            log_ok("Ollama is running")
            models = r.json().get("models", [])
            if models:
                log_info(f"Available models: {', '.join(m.get('name','?') for m in models[:4])}")
            else:
                if config['ollama_model']:
                    log_warn(f"No models — run: ollama pull {config['ollama_model']}")
                else:
                    log_warn("No models — pull one with 'ollama pull <model>' and set it as the Ollama model in Settings")
        else:
            log_warn("Ollama responded but something seems off")
    except Exception:
        log_warn("Ollama not detected — start it with: ollama serve")

if __name__ == "__main__":
    banner()
    startup_guide()

    provider = config.get("llm_provider", "ollama")
    if provider == "openai":
        log_ok(f"Using OpenAI ({config.get('openai_model')})") if config.get("openai_api_key", "").strip() \
            else log_warn("OpenAI selected but no API key set — add one in Settings")
    elif provider == "gemini":
        log_ok(f"Using Gemini ({config.get('gemini_model')})") if config.get("gemini_api_key", "").strip() \
            else log_warn("Gemini selected but no API key set — add one in Settings")
    else:
        check_ollama()

    tts_settings = get_effective_tts_config()
    engine = tts_settings.get("tts_engine")
    if engine == "piper":
        model = tts_settings.get("piper_model", "")
        log_ok(f"Piper TTS: {model}") if model and os.path.exists(model) else log_warn(f"Piper selected but model not found: '{model}' — set in Settings → Character")
    elif engine == "gptsovits":
        log_ok(f"GPT-SoVITS: {tts_settings.get('gptsovits_url')}") if tts_settings.get("gptsovits_ref_audio") else log_warn("GPT-SoVITS selected but no ref audio set — configure in Settings → Character")
    elif engine == "browser":
        log_info("TTS: browser (Web Speech API) — nothing extra to install")
    else:
        log_warn("No voice set for the active character — set one in Settings → Character")

    if config.get("vts_enabled"):
        threading.Thread(target=_connect_vts, daemon=True).start()
    else:
        log_info("VTube Studio integration disabled — enable it in Settings")

    sync_stream_platforms()
    if not any(config.get(k) for k in ("twitch_enabled", "youtube_enabled", "kick_enabled")):
        log_info("Stream chat (Twitch/YouTube/Kick) disabled — enable it in Settings")

    print()
    log_ok("Control panel  ->  http://localhost:5000")
    print(f"\n  {T.GREY}{'─'*60}{T.RESET}")
    print(f"  {T.DIM}Waiting for messages...{T.RESET}\n")

    logging.getLogger('werkzeug').setLevel(logging.ERROR)
    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
