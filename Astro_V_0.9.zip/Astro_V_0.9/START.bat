@echo off
title Astro V v0.9 - Starting...
color 0D

cls
echo.
echo   ==============================================================
echo.
echo          ASTRO V0.9  --  Setup and Launch
echo.
echo   ==============================================================
echo.
echo   This will install everything and start the control panel.
echo   Keep this window open while you use it.
echo.
echo   --------------------------------------------------------------
echo.

REM -- CHECK PYTHON --
python --version >nul 2>&1
if errorlevel 1 (
    echo   [ERROR] Python is not installed or not in PATH!
    echo.
    echo   Fix:
    echo     1. Go to https://www.python.org/downloads/
    echo     2. Download Python 3.11 or newer
    echo     3. Run the installer
    echo     4. On the FIRST screen, tick "Add Python to PATH"
    echo     5. Then double-click this file again
    echo.
    pause
    exit /b 1
)

echo   [OK] Python found
python --version

REM -- SET UP VENV --
if not exist "venv" (
    echo.
    echo   [SETUP] Creating virtual environment first time only...
    python -m venv venv
    if errorlevel 1 (
        echo   [ERROR] Failed to create virtual environment.
        echo   Try running: python -m pip install --upgrade pip
        pause
        exit /b 1
    )
    echo   [OK] Virtual environment created
)

REM -- ACTIVATE --
call venv\Scripts\activate.bat
if errorlevel 1 (
    echo   [ERROR] Could not activate virtual environment.
    echo   If you see a script policy error, open PowerShell as Admin and run:
    echo     Set-ExecutionPolicy RemoteSigned
    pause
    exit /b 1
)

REM -- INSTALL PACKAGES --
echo.
echo   [SETUP] Installing / checking required packages...
pip install -r requirements.txt -q --disable-pip-version-check
if errorlevel 1 (
    echo   [ERROR] Failed to install packages. Check your internet connection.
    pause
    exit /b 1
)
echo   [OK] All packages ready

REM -- CHECK OLLAMA --
echo.
curl -s http://localhost:11434/api/tags >nul 2>&1
if errorlevel 1 (
    echo   [WARN] Ollama doesn't seem to be running!
    echo.
    echo   To fix: Open a NEW terminal window and type:
    echo     ollama serve
    echo.
    echo   Then press any key here to continue anyway...
    echo   Messages will fail until Ollama is running
    echo   (Or switch to OpenAI / Gemini in Settings instead.)
    pause >nul
) else (
    echo   [OK] Ollama is running
)

REM -- START --
cls
echo.
echo   ==============================================================
echo.
echo          ASTRO V0.9  --  Running
echo.
echo   ==============================================================
echo.
echo     Control Panel   -^>  http://localhost:5000
echo.
echo   --------------------------------------------------------------
echo.
echo     Everything is configured from the web control panel:
echo     click the Settings gear to set your TTS engine, LLM
echo     provider, Twitch channel, and VTube Studio connection.
echo.
echo   ==============================================================
echo.
echo   Keep this window open while using the control panel!
echo   --------------------------------------------------------------
echo.

REM -- AUTO-OPEN CONTROL PANEL IN BROWSER --
start "" /min cmd /c "timeout /t 3 /nobreak >nul & start http://localhost:5000"

python server.py

echo.
echo   [STOPPED] The server has shut down.
pause
