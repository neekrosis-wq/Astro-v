"""
expressions.py — Keyword-based emotion detection for the tsundere AI.

Scans text for keywords and returns the matching emotion. Used two ways:
  1. Feeds VTube Studio's ExpressionController (activates a .exp3.json file
     on your model, if VTS is connected).
  2. Feeds the emotion state broadcast over SSE (/api/state), which the
     Expressions tester in the control panel uses to report Mey's mood.

Moods (emoji, expression file, trigger keywords) are no longer hardcoded
here — they live in config.json and are editable from Settings >
Expressions, including adding entirely new moods. DEFAULT_MOODS below is
just the seed data used the very first time the app runs, before
config.json exists. At runtime, server.py calls load_moods() with whatever
config.json actually has, and everything in this file reads from that.

To see what your model's real expression filenames are, use the "List my
model's expressions" button on the Expressions tab in the control panel
(requires VTube Studio to be connected).
"""

import re
import logging
import threading

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Seed data — only used to populate config.json on first run
# ---------------------------------------------------------------------------

DEFAULT_MOODS: dict[str, dict] = {
    "angry": {
        "emoji": "😠", "file": None,
        "keywords": ["hmph", "annoying", "irritating", "bother", "stupid", "idiot",
                     "leave me alone", "ugh", "whatever", "don't talk to me"],
    },
    "blush": {
        "emoji": "😳", "file": None,
        "keywords": ["embarrassed", "embarrassing", "not like i care", "don't get the wrong idea",
                     "it's nothing", "i-it's not", "blush", "flustered", "w-well", "b-baka"],
    },
    "surprised": {
        "emoji": "😲", "file": None,
        "keywords": ["what?!", "no way", "seriously?", "really?", "i can't believe",
                     "shocked", "unexpected", "wait what", "huh?"],
    },
    "smug": {
        "emoji": "😏", "file": None,
        "keywords": ["obviously", "of course", "naturally", "as expected", "told you",
                     "i knew it", "pathetic", "amateur", "impressive? i know"],
    },
    "sad": {
        "emoji": "😢", "file": None,
        "keywords": ["sorry", "forgive", "lonely", "miss", "wish", "unfortunate",
                     "that's sad", "poor", "hurt"],
    },
    "happy": {
        "emoji": "😊", "file": None,
        "keywords": ["glad", "happy", "great", "wonderful", "amazing", "love",
                     "thank you", "hehe", "ehehe", "yay", "nice"],
    },
    "neutral": {"emoji": "😐", "file": None, "keywords": []},
}

# The active registry — replaced wholesale by load_moods(), never mutated
# in place, so a reference someone grabbed via get_moods() earlier is never
# silently changed out from under them.
_moods: dict[str, dict] = {k: dict(v) for k, v in DEFAULT_MOODS.items()}


def load_moods(moods: dict[str, dict]) -> None:
    """Replace the active mood registry — called once at startup with
    whatever's in config.json, and again any time moods are added, edited,
    or removed from Settings > Expressions so the change takes effect
    immediately without a restart."""
    global _moods
    cleaned: dict[str, dict] = {}
    for key, m in (moods or {}).items():
        cleaned[key] = {
            "emoji": (m.get("emoji") or "🙂").strip() or "🙂",
            "file": (m.get("file") or "").strip() or None,
            "keywords": [kw.strip() for kw in m.get("keywords", []) if kw.strip()],
        }
    if "neutral" not in cleaned:
        cleaned["neutral"] = {"emoji": "😐", "file": None, "keywords": []}
    _moods = cleaned


def get_moods() -> dict[str, dict]:
    """The full active registry, in display order."""
    return _moods


def emotion_keys() -> list[str]:
    return list(_moods.keys())


def is_known_emotion(emotion: str) -> bool:
    return emotion in _moods


def get_emoji(emotion: str) -> str:
    return _moods.get(emotion, {}).get("emoji", "😐")


def get_expression_file(emotion: str):
    return _moods.get(emotion, {}).get("file")


# Keywords that trigger each emotion, in registry order — first match wins.
def detect_emotion(text: str) -> str:
    """Return the first matching emotion key, or 'neutral'.

    Uses (?<!\\w) / (?!\\w) instead of \\b on each side. \\b requires an actual
    word/non-word *transition*, which silently fails to match a keyword that
    ends in punctuation (e.g. "what?!", "huh?") when it's immediately
    followed by more punctuation or end-of-string — both sides end up
    non-word, so no boundary exists and \\b never fires. The lookaround
    version only checks each side independently, so punctuation-ending
    keywords still match correctly at a real word edge."""
    lowered = text.lower()
    for emotion, m in _moods.items():
        for kw in m.get("keywords", []):
            if re.search(rf"(?<!\w){re.escape(kw)}(?!\w)", lowered):
                return emotion
    return "neutral"


# ---------------------------------------------------------------------------
# Explicit [emotion:x] tag support
# ---------------------------------------------------------------------------
# The system prompt asks the model to prefix every reply with a tag like
# "[emotion:happy]" naming its own mood. This is far more reliable than
# guessing from word choice, since the model already knows what it's going
# for. Keyword detection (above) remains as a fallback for when the model
# forgets, or when using a small local model that doesn't reliably follow
# formatting instructions.

_EMOTION_TAG_RE = re.compile(r"\[\s*emotion\s*:\s*([a-zA-Z]+)\s*\]", re.IGNORECASE)


def extract_emotion_tag(text: str) -> tuple[str | None, str]:
    """Look for an [emotion:x] tag anywhere in `text`.

    Returns (emotion, text_with_tag_removed) if a *known* emotion tag was
    found, or (None, text) unchanged otherwise (unknown tag names are left
    in place rather than silently eaten, so a typo'd tag is still visible
    for debugging instead of just vanishing)."""
    m = _EMOTION_TAG_RE.search(text)
    if not m:
        return None, text
    tag = m.group(1).lower()
    if not is_known_emotion(tag):
        return None, text
    remaining = text[:m.start()] + text[m.end():]
    return tag, remaining


class ExpressionController:
    """Detects emotion in text and updates the active VTube Studio expression.

    idle_timeout: seconds of inactivity (no new update()/apply() call)
    after which an active (non-neutral) expression automatically reverts
    to neutral. None or 0 disables auto-revert entirely — the previous
    "stays on forever" behavior. Every successful switch (or a repeated
    hit on the same emotion) restarts the clock, so it only fires after
    genuine silence, not after a fixed time from when the mood first
    appeared.
    """

    def __init__(self, vts, idle_timeout: float | None = None) -> None:
        self._vts = vts
        self._current: str | None = None
        self._idle_timeout = idle_timeout
        self._idle_timer: threading.Timer | None = None
        self._lock = threading.Lock()
        # Guards the actual deactivate-old/activate-new sequence. Without
        # this, two near-simultaneous calls (e.g. clicking Test on two
        # moods back-to-back before the first VTS round-trip finishes)
        # can both read the same stale self._current, both skip
        # deactivating each other's target, and leave two expressions
        # active on the model at once.
        self._switch_lock = threading.RLock()

    def update(self, text: str) -> str:
        """Scan text, switch VTS expression if it changed, return the emotion key."""
        emotion = detect_emotion(text)
        return self.apply(emotion)

    def apply(self, emotion: str) -> str:
        """Set a *known* emotion directly, bypassing keyword detection. Used
        when the emotion came from the model's own [emotion:x] tag rather
        than being guessed from the text. Falls back to 'neutral' for
        anything not in the current mood registry."""
        if not is_known_emotion(emotion):
            emotion = "neutral"
        with self._switch_lock:
            if emotion != "neutral" and emotion != self._current:
                self._switch(emotion)
            elif emotion == "neutral" and self._current:
                self.reset()
            # Any activity — including repeated hits on the same emotion —
            # pushes the idle clock back, so a mood that keeps getting
            # re-confirmed doesn't expire mid-conversation.
            if emotion != "neutral":
                self._arm_idle_timer()
            else:
                self._cancel_idle_timer()
        return emotion

    def reset(self) -> None:
        with self._switch_lock:
            self._cancel_idle_timer()
            if self._current:
                self._deactivate(self._current)
                self._current = None

    # --- Idle auto-revert -----------------------------------------------

    def _arm_idle_timer(self) -> None:
        if not self._idle_timeout:
            return
        with self._lock:
            if self._idle_timer:
                self._idle_timer.cancel()
            self._idle_timer = threading.Timer(self._idle_timeout, self._on_idle)
            self._idle_timer.daemon = True
            self._idle_timer.start()

    def _cancel_idle_timer(self) -> None:
        with self._lock:
            if self._idle_timer:
                self._idle_timer.cancel()
                self._idle_timer = None

    def _on_idle(self) -> None:
        logger.info("Expression idle for %.0fs -> reverting to neutral", self._idle_timeout)
        self.reset()

    def preview(self, emotion: str) -> tuple[bool, str]:
        """Manually force an emotion, bypassing keyword detection. Used by the
        Settings > Expressions tester so you can check each mood on demand.
        Returns (success, error_message) reflecting what VTube Studio
        actually reported — 'ok, no error' is not assumed just because a
        file mapping exists."""
        if not is_known_emotion(emotion):
            raise ValueError(f"Unknown emotion: {emotion}")
        with self._switch_lock:
            if emotion == "neutral":
                self.reset()
                return True, ""
            file = get_expression_file(emotion)
            if not self._vts or not self._vts.is_ready():
                return False, "VTube Studio is not connected"
            if self._current:
                self._deactivate(self._current)
                self._current = None
            ok, err = self._vts.set_expression(file, True)
            if ok:
                self._current = emotion
                self._arm_idle_timer()
            return ok, err

    def _switch(self, emotion: str) -> None:
        if self._current:
            self._deactivate(self._current)
            self._current = None
        file = get_expression_file(emotion)
        if not file:
            # Nothing to confirm with VTS — this mood is just a badge change,
            # so it's safe to consider it "current" immediately.
            self._current = emotion
            return
        if not self._vts or not self._vts.is_ready():
            # Can't confirm the switch actually happened. Deliberately leave
            # self._current unset (rather than optimistically assuming it
            # worked) so that if this same mood gets re-confirmed later —
            # e.g. once VTS reconnects — apply() sees it as different from
            # self._current and retries the real VTS call instead of
            # silently skipping it forever.
            return
        ok, err = self._vts.set_expression(file, True)
        if ok:
            logger.info("Expression -> %s (%s)", emotion, file)
            self._current = emotion
        else:
            logger.warning("Failed to activate expression %s: %s", file, err)

    def _deactivate(self, emotion: str) -> None:
        file = get_expression_file(emotion)
        if file and self._vts and self._vts.is_ready():
            self._vts.set_expression(file, False)
