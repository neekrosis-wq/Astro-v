"""
vtube_studio.py — VTube Studio WebSocket API integration.

Same client as the original project, with two changes:
  - host/port are passed in by the caller (from config.json) instead of a
    static config.py import, so Settings changes apply without editing code.
  - websocket-client is now an OPTIONAL dependency: if it's not installed,
    connect() just returns False with a warning instead of crashing the
    whole server at import time.
"""

import json
import threading
import time
import uuid
import logging
from typing import Optional

logger = logging.getLogger(__name__)

try:
    import websocket
    _WS_AVAILABLE = True
except ImportError:
    websocket = None
    _WS_AVAILABLE = False

TOKEN_FILE       = ".vts_auth_token"
PLUGIN_NAME      = "Astro V"
PLUGIN_DEVELOPER = "Neekrosis"
SPEAKING_PARAM   = "AstroMouthOpen"


class VTubeStudio:
    """Minimal VTube Studio WebSocket API client."""

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 8001,
    ) -> None:
        self._url = f"ws://{host}:{port}"
        self._ever_connected  = False   # flips True only after a successful first connection
        self._ws: Optional["websocket.WebSocketApp"] = None
        self._ws_thread: Optional[threading.Thread] = None
        self._connected       = threading.Event()
        self._authenticated   = threading.Event()
        self._pending: dict[str, dict] = {}
        self._pending_lock    = threading.Lock()
        self._response_events: dict[str, threading.Event] = {}
        self._auth_token: Optional[str] = self._load_token()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def connect(self, timeout: float = 10.0) -> bool:
        if not _WS_AVAILABLE:
            logger.warning("VTube Studio: websocket-client not installed — pip install websocket-client")
            return False

        self._ws = websocket.WebSocketApp(
            self._url,
            on_open=self._on_open,
            on_message=self._on_message,
            on_error=self._on_error,
            on_close=self._on_close,
        )
        self._ws_thread = threading.Thread(
            target=self._ws.run_forever, daemon=True, name="vts-ws"
        )
        self._ws_thread.start()

        if not self._connected.wait(timeout):
            logger.warning("VTube Studio: could not connect to %s", self._url)
            return False

        ok = self._authenticate(timeout)
        if ok:
            self._ever_connected = True
        return ok

    def disconnect(self) -> None:
        if self._ws:
            self._ws.close()

    def is_ready(self) -> bool:
        return self._connected.is_set() and self._authenticated.is_set()

    def get_hotkeys(self) -> list[dict]:
        resp = self._request(
            "HotkeyTriggerRequest", {"modelID": "", "hotkeyID": ""},
            message_type_override="HotkeysInCurrentModelRequest"
        )
        return resp.get("data", {}).get("availableHotkeys", [])

    def trigger_hotkey(self, hotkey_id_or_name: str) -> bool:
        resp = self._request("HotkeyTriggerRequest", {"hotkeyID": hotkey_id_or_name})
        return "hotkeyID" in resp.get("data", {})

    def get_expressions(self) -> list[dict]:
        resp = self._request("ExpressionStateRequest", {"details": True})
        return resp.get("data", {}).get("expressions", [])

    def set_expression(self, expression_file: str, active: bool) -> tuple[bool, str]:
        """Returns (success, error_message). success is False if VTS rejected
        the request — most commonly because expression_file doesn't match
        any file actually loaded on the current model.

        note: a successful ExpressionActivationResponse from VTS has an
        EMPTY data object — it never echoes expressionFile back. Checking
        for that field (as this used to) meant success was never detected
        even when VTS genuinely activated the expression; only the
        messageType reliably distinguishes success from APIError."""
        t0 = time.monotonic()
        resp = self._request("ExpressionActivationRequest", {
            "expressionFile": expression_file,
            "active": active,
        }, timeout=10.0)
        elapsed = time.monotonic() - t0
        logger.info(
            "set_expression(%r, active=%s) took %.2fs, raw response: %s",
            expression_file, active, elapsed, resp,
        )
        if not resp:
            return False, "No response from VTube Studio (request may have timed out)"
        msg_type = resp.get("messageType")
        if msg_type == "ExpressionActivationResponse":
            return True, ""
        if msg_type == "APIError":
            err = resp.get("data", {})
            return False, err.get("message", "VTube Studio rejected the request")
        return False, f"Unexpected response from VTube Studio ({msg_type})"

    def inject_parameter(self, param_name: str, value: float, weight: float = 1.0) -> bool:
        resp = self._request("InjectParameterDataRequest", {
            "faceFound": False,
            "mode": "set",
            "parameterValues": [{"id": param_name, "value": value, "weight": weight}],
        })
        return resp.get("messageType") == "InjectParameterDataResponse"

    def set_speaking(self, speaking: bool) -> None:
        if not self.is_ready():
            return
        self.inject_parameter(SPEAKING_PARAM, 1.0 if speaking else 0.0)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _request(self, message_type, data, timeout=5.0, message_type_override=None):
        if not self._connected.is_set():
            return {}
        req_id = str(uuid.uuid4())
        payload = {
            "apiName":     "VTubeStudioPublicAPI",
            "apiVersion":  "1.0",
            "requestID":   req_id,
            "messageType": message_type_override or message_type,
            "data":        data,
        }
        evt = threading.Event()
        with self._pending_lock:
            self._response_events[req_id] = evt
        self._ws.send(json.dumps(payload))
        if not evt.wait(timeout):
            with self._pending_lock:
                self._response_events.pop(req_id, None)
                self._pending.pop(req_id, None)
            return {}
        with self._pending_lock:
            return self._pending.pop(req_id, {})

    def _authenticate(self, timeout):
        if self._auth_token:
            resp = self._request("AuthenticationRequest", {
                "pluginName":          PLUGIN_NAME,
                "pluginDeveloper":     PLUGIN_DEVELOPER,
                "authenticationToken": self._auth_token,
            })
            if resp.get("data", {}).get("authenticated"):
                self._authenticated.set()
                return True
            self._auth_token = None

        resp = self._request("AuthenticationTokenRequest", {
            "pluginName":      PLUGIN_NAME,
            "pluginDeveloper": PLUGIN_DEVELOPER,
            "pluginIcon":      "",
        }, timeout=30.0)
        token = resp.get("data", {}).get("authenticationToken", "")
        if not token:
            return False
        self._auth_token = token
        self._save_token(token)

        resp = self._request("AuthenticationRequest", {
            "pluginName":          PLUGIN_NAME,
            "pluginDeveloper":     PLUGIN_DEVELOPER,
            "authenticationToken": token,
        })
        if resp.get("data", {}).get("authenticated"):
            self._authenticated.set()
            return True
        return False

    # --- WebSocket callbacks -------------------------------------------

    def _on_open(self, ws):
        self._connected.set()

    def _on_message(self, ws, raw):
        try:
            msg = json.loads(raw)
        except json.JSONDecodeError:
            return
        req_id = msg.get("requestID")
        if req_id:
            with self._pending_lock:
                self._pending[req_id] = msg
                evt = self._response_events.pop(req_id, None)
            if evt:
                evt.set()

    def _on_error(self, ws, error):
        # Only log errors if we were previously connected — suppresses
        # the flood of "connection refused" errors when VTS is simply not open
        if self._ever_connected:
            logger.warning("VTS error: %s", error)

    def _on_close(self, ws, code, msg):
        self._connected.clear()
        self._authenticated.clear()
        if self._ever_connected:
            logger.info("VTS disconnected — use the Reconnect button in Settings to reconnect")

    # --- Token persistence --------------------------------------------

    @staticmethod
    def _load_token():
        try:
            with open(TOKEN_FILE, "r", encoding="utf-8") as f:
                return f.read().strip() or None
        except FileNotFoundError:
            return None

    @staticmethod
    def _save_token(token):
        try:
            with open(TOKEN_FILE, "w", encoding="utf-8") as f:
                f.write(token)
        except OSError as e:
            logger.warning("Could not save token: %s", e)
