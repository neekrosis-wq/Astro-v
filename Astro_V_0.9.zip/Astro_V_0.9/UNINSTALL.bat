@echo off
title Astro V v0.9 - Uninstaller
color 0C

cls
echo.
echo   ==============================================================
echo          ASTRO V0.9  --  Uninstaller
echo   ==============================================================
echo.
echo   This will remove the virtual environment and installed
echo   packages (the "venv" folder).
echo.
echo   Your settings and data are KEPT by default:
echo     - config.json
echo     - memory.json
echo     - characters.json
echo.
echo   --------------------------------------------------------------
echo.

REM -- Make sure we are running from the folder this file is in --
cd /d "%~dp0"
echo   Working folder: %cd%
echo.

set /p CONFIRM="   Remove the virtual environment now? (Y/N): "
if /i not "%CONFIRM%"=="Y" (
    echo.
    echo   Cancelled. Nothing was removed.
    echo.
    pause
    exit /b 0
)

echo.
echo   [1/2] Removing virtual environment...
if exist "venv" (
    rmdir /s /q "venv"
    if exist "venv" (
        echo   [ERROR] Could not fully remove "venv". It may be in use.
        echo   Close any running Astro V window and try again.
        pause
        exit /b 1
    )
    echo   [OK] Virtual environment removed
) else (
    echo   [SKIP] No "venv" folder found
)
echo.

echo   [2/2] Removing cached Python files...
for /d /r %%d in (__pycache__) do (
    if exist "%%d" rmdir /s /q "%%d"
)
echo   [OK] Cache cleaned
echo.

echo   ==============================================================
echo          UNINSTALL COMPLETE
echo   ==============================================================
echo.
echo   The venv and cached files have been removed.
echo   Your config.json, memory.json, and characters.json were kept.
echo.
echo   Run INSTALL.bat (or START.bat) again any time to reinstall.
echo.

set /p WIPEALL="   Also permanently delete the ENTIRE Astro V folder, including your settings and data? (type YES to confirm): "
if /i not "%WIPEALL%"=="YES" (
    echo.
    echo   Keeping the app folder. Uninstall finished.
    echo.
    pause
    exit /b 0
)

echo.
echo   Deleting the entire folder in 5 seconds... Close this window now to cancel!
timeout /t 5

REM -- Self-delete the whole app folder, including this script, after the window closes --
set "TARGET=%cd%"
cd /d "%TEMP%"
start "" cmd /c "timeout /t 1 >nul & rmdir /s /q "%TARGET%""
exit
