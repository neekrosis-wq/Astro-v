@echo off
title Astro V v0.9 - Installer
color 0A

cls
echo.
echo   ==============================================================
echo          ASTRO V0.9  --  Installer
echo   ==============================================================
echo.
echo   This will set up everything needed to run the control panel.
echo.
echo   --------------------------------------------------------------
echo.

REM -- Make sure we are running from the folder this file is in --
cd /d "%~dp0"
echo   Working folder: %cd%
echo.

REM -- CHECK PYTHON --
echo   [1/4] Checking Python...
python --version
if errorlevel 1 (
    echo.
    echo   [ERROR] Python is not installed or not working.
    echo   Fix:
    echo     1. Go to https://www.python.org/downloads/
    echo     2. Download and run the installer
    echo     3. On the FIRST screen, tick "Add python.exe to PATH"
    echo     4. Run this installer again
    echo.
    pause
    exit /b 1
)
echo   [OK] Python is working
echo.

REM -- REMOVE BROKEN VENV IF PRESENT --
if exist "venv\Scripts\python.exe" (
    echo   [2/4] Existing virtual environment found, checking it...
    venv\Scripts\python.exe --version >nul 2>&1
    if errorlevel 1 (
        echo   [WARN] Existing venv looks broken, rebuilding it...
        rmdir /s /q venv
    ) else (
        echo   [OK] Existing venv looks fine
    )
) else (
    if exist "venv" (
        echo   [WARN] Incomplete venv folder found, removing it...
        rmdir /s /q venv
    )
)

REM -- CREATE VENV --
if not exist "venv" (
    echo   [2/4] Creating virtual environment...
    python -m venv venv
    if errorlevel 1 (
        echo.
        echo   [ERROR] Failed to create the virtual environment.
        echo   Try: python -m pip install --upgrade pip
        echo.
        pause
        exit /b 1
    )
    echo   [OK] Virtual environment created
)
echo.

REM -- VERIFY VENV PYTHON EXISTS --
if not exist "venv\Scripts\python.exe" (
    echo   [ERROR] venv\Scripts\python.exe is missing after setup.
    echo   Your Python install may still be broken. Try reinstalling Python
    echo   from https://www.python.org/downloads/ and run this again.
    echo.
    pause
    exit /b 1
)

REM -- UPGRADE PIP INSIDE THE VENV --
echo   [3/4] Upgrading pip...
venv\Scripts\python.exe -m pip install --upgrade pip -q
echo   [OK] pip is up to date
echo.

REM -- INSTALL REQUIREMENTS --
echo   [4/4] Installing required packages from requirements.txt...
echo   This may take a minute, please wait...
echo.
venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo   [ERROR] Some packages failed to install.
    echo   Scroll up to see which package failed and why.
    echo   Common causes: no internet connection, or a typo in requirements.txt.
    echo.
    pause
    exit /b 1
)

echo.
echo   ==============================================================
echo          INSTALL COMPLETE
echo   ==============================================================
echo.
echo   All packages are installed. You can now run START.bat
echo   to launch the control panel.
echo.
pause
