# Astro V v0.9 (Web Panel Edition)

## What is Astro?
Astro is a browser-based app that lets you run an AI chatbot/streaming companion, similar to Neuro-sama. 
It can be paired with other apps — Ollama, VTube Studio, and GPT-SoVITS.

*Astro was created by Neekrosis to give everyone a streamlined AI streaming
companion/chatbot that works straight out of the box with minimal setup. Since
Astro is fully editable, you can grab the base model from [link].

*Thanks for using Astro — have fun with it!*

*— Neekrosis*

The README covers the key info to get started. If you're still stuck on something, 
the `Astro_V_Guide_Booklet.docx` goes into full detail and should answer just about
any question you have.



## Key features

- **Browser-based control panel** — A single-page browser interface at http://localhost:5000 
that updates live. Open Astros ui Settings to change anything directly, without having to edit the config file by hand.

- **Multiple switchable characters** — three built-in Character (Mey,
  Kaname, Yuki) plus a  Character creator "New Character" wizard that has the LLM generate a
  Built-in characters' persona fields are read-only (voice is still
  editable) and they can't be deleted; characters you create can be both
  edited and deleted.

- **Per-character stream trigger words**— “Settings” → “Stream” → “Names chat uses”: 
The names/nicknames Chat uses when talking to a character are saved per character, rather than globally.
 Switching characters loads that character’s own saved list. If a character doesn’t have a saved list yet,
  it defaults to that character’s name plus any currently active names that don’t belong to another character.
  This means generic additions, such as a channel nickname, will carry over between characters.

- **Three TTS engines, switchable per character** — Browser (zero setup),
  Piper (local neural TTS), or GPT-SoVITS (best quality, most setup for voice cloning).

- **Browser-based mic input** — push-to-talk, always-on, or hold-to-talk,
  all built on the Web Speech API. No PyAudio install required.

- **Multi-platform stream chat** — Twitch, YouTube, and Kick chat listening
  can all run at once, with voice-only replies to mentions and questions.

- **VTube Studio integration** — expression control and mouth-flap, toggled
  from Settings rather than always running.

- **Fully editable moods and expressions** — add or edit moods live from
  Settings → Expressions, no code editing needed.

**Interruptible TTS** start talking as the character's speeks, speech cuts off immediately, so conversations feel more like a real back-and-forth instead of waiting for it to finish.
- **Persistent, per-character memory** — each character remembers facts
  about you between sessions, with backup/restore for your whole setup.



## Set up

If you do not have an API key, you will need to install Ollama — see
[Ollama setup](#ollama-setup). If you want to run Astro with an API key,
you can skip Ollama setup  — see [VTube Studio setup](#VTube-Studio-setup)  


## Ollama setup

Ollama is the default LLM backend — free, local, no account or API key.

Astro was built/tested using **Llama 3** through Ollama. If your PC can handle it comfortably, **I recommend using Llama 3** because that is the model family the project was developed around. The exact Llama 3 variant and quantization you should use depends on your hardware; if it is too heavy, use a smaller or quantized model that fits comfortably. Local Llama-family inference can use quantization and GPU acceleration to reduce memory pressure and improve performance. If
you already have it running, Astro just works; if not:

1. Install Ollama from [ollama.com](https://ollama.com/).

2. Open the Ollama app and install a llm model — **Llama 3 is recommended if
   your PC can handle it**; otherwise use a smaller or quantized model
   that fits comfortably.


### Reducing LLM response time

If Astro feels slow before it starts speaking, try these in roughly this order: (The first response will take longer)
  
- **Keep Ollama running** so the model stays loaded instead of repeatedly starting from cold.

- **Change Ollama models.** The LLM model may be too heavy — try switching to a less powerful model.

- **Use a quantized model/variant that fits comfortably in VRAM/RAM.** A model that constantly spills into system RAM or swaps can feel much slower.
 llama.cpp supports multiple quantization levels and CPU/GPU hybrid inference.

- **Use GPU acceleration/offload when available.** Keeping the model on the GPU avoids the large slowdown of CPU-only or heavy CPU+GPU fallback.

- **Keep Astro's conversation context reasonable.** Lowering the number of past messages reduces the amount of text the LLM has to process on each request.

- **Keep the character/system prompt focused.** Very long personality notes, memories, and instructions increase prompt-processing work.

- **Avoid running out of VRAM.** If the model barely fits, lowering context size or using a smaller/quantized model can be faster overall than forcing memory fallback. llama.cpp notes that KV-cache memory grows with context size.

- **Close other GPU-heavy programs** while testing.

**Quick rule:** the fastest setup is usually the largest model that fits comfortably in your available VRAM/RAM without swapping or heavy CPU fallback.


## GPT-SoVITS setup 
(optional)

GPT-SoVITS is the highest-quality TTS engine, but the most setup — it's a
separate service Astro talks to over HTTP, not something Astro installs or
bundles. GPT-SoVITS needs a reference audio clip (about 8 seconds) and its
transcript — an example is provided in the Astro folder under the name voice_refs.

1. Download GPT-SoVITS from [github.com/RVC-Boss/GPT-SoVITS](https://github.com/RVC-Boss/GPT-SoVITS).
   If you're a Windows user (tested with Windows 10+), download the
   integrated package 

2. Extract GPT-SoVITS, open the folder, right-click inside it and choose
   "Open terminal," then paste in

   .\runtime\python.exe api_v2.py -a 127.0.0.1 -p 9880 -c GPT_SoVITS/configs/tts_infer.yaml
   
   hit enter 


3. This starts/launches its API server with `api_v2.py`, not the older
   `api.py` — only `api_v2.py`'s request format matches what Astro sends.
   First launch can take a minute or two while it loads weights — that's
   normal. You're ready when the console shows `Uvicorn running on
   http://127.0.0.1:9880`. Closing that window stops GPT-SoVITS from working.


4. Get a short reference voice clip (a .wav file) of the voice you want to
   clone, plus the transcript spoken in that clip.

   - **Reference audio** — **full absolute path** 

     I have provided an example in the Astro folder under the file name `"voice_refs"` — copy and past the `voice_refs` 
     folder and drop it into the GPT-SoVITS folder.
     If you want to use a custom voice, replace the `.wav` file and transcript in both `voice_refs` folders with the voice you want to use.

   - **Reference text** — the exact text spoken in the reference clip,
     word-for-word — GPT-SoVITS doesn't read this from a file, it only
     ever sees what you type here.

   - **Language** — defaults to Japanese (`ja`); change if your reference
     clip is in another language.



## GPT-SoVITS voice_refs example

The project includes an example `voice_refs` folder with a sample reference audio file (`1.wav`) and its matching transcript (`Reference audio's transcript text.txt`). This is provided as an example of the folder/file layout GPT-SoVITS can use for a reference voice.

If you want, you can simply drop/copy the entire `voice_refs` folder into your GPT-SoVITS folder. When the GPT-SoVITS API is launched from that folder, a reference path such as `voice_refs\\1.wav` can be used. An absolute path is still the safest option if you are unsure which directory the API server is using.




## Set up Astro

1. If you want to use VTube Studio and/or GPT-SoVITS, set those up first —
   see [VTube Studio setup](#vtube-studio-setup), [GPT-SoVITS setup](#gpt-sovits-setup),
   
2. **Windows:** double-click `INSTALL.bat` once. **Anything else:**
   `pip install -r requirements.txt`.

3. Follow the [Launch order](#launch-order) below, then run `START.bat`
   every time after — this will open Astro's terminal and the Astro UI.
   `DO NOT CLOSE the Astro terminal while you are using the UI.`


## YouTube, Twitch and Kick setup

Twitch and Kick chat work with just your channel name — no account or key
needed. YouTube requires a free API key:

1. Go to the [Google Cloud Console](https://console.cloud.google.com/),
   create a project (or use an existing one).
2. Enable the **YouTube Data API v3** for that project.
3. Create an API key under Credentials.

Live video ID — from the URL when you're streaming live. Go to your live stream (either the studio preview or the public watch page), and look at the URL:

https://www.youtube.com/watch?v=dQw4w9WgXcQ ← that part after v= is the video ID.

You can also get it from YouTube Studio → Content → Live tab, click your active/upcoming stream, and the ID is in that URL too.


Channel ID — not the same as your @handle. To find it:

1. Go to your own channel page while logged in, click your profile icon → Your channel.
2. Click Share channel → Copy channel ID, or check the page URL if it's in the youtube.com/channel/UC... format (starts with UC).
3. Alternatively: YouTube Studio → Settings → Channel → Advanced settings, your Channel ID is listed there.

## Make a note of the Youtube api and Channel ID

## Virtual audio cable setup

Every TTS engine plays back through whatever browser tab has the control
panel open, so a virtual audio cable (e.g. [VB-Cable](https://vb-audio.com/Cable/),
free) is how you get that audio somewhere else — either into VTube Studio
for real waveform-driven lip sync, or into OBS as its own isolated track.
Nothing in Astro needs to change; one cable route covers every TTS engine
since they all play back through the same tab. Without this, VTube Studio
would pick up whatever sound is playing on your system, and the avatar's
mouth would move for all sound — not just the character's speech, We are essentially
using the virtual cable as a virtal mic for the character's.

1. Install the [virtual cable](https://vb-audio.com/Cable/).
Once installed it will tell you to restart your pc 

2. To Set Astro's browser audio to VB-Cable Go to Windows Settings open System → Sound → Volume mixer.

3. Find your browser under Apps — e.g. Chrome, Edge, or Firefox. choose Edge( or base browser ) That is what Astro should use. if  
opens in different browser go back and change it 

4. Set its Output device to:
CABLE Input (VB-Audio Virtual Cable)

CABLE Input (VB-Audio Virtual Cable) — programs send audio into this.
CABLE Output (VB-Audio Virtual Cable) — programs receive audio from this.

5. Restart/refresh the Astro tab and test the TTS again.


Now anything that Astro plays through that browser— including Browser TTS, Piper, or GPT-SoVITS—goes through the cable.
CABLE Output

You can then put that source on its own OBS audio track and input to Vtube studios.

If you want to hear the character through your own speakers while using VB-Cable, you can optionally enable “Listen to this device” for the cable output in Windows.

On Windows, you do it from the CABLE Output device properties:

1. Right-click the speaker icon in your Windows taskbar.
2. Select Sound settings.
3. Scroll down and click More sound settings.
4. Open the Recording tab.
5. Find CABLE Output (VB-Audio Virtual Cable).
6. Right-click it → Properties.
7. Open the Listen tab.
8. Check Listen to this device.
9. Under Playback through this device, choose your normal speakers/headphones.
10. Click Apply → OK.


## VTube Studio setup

VTube Studio is a separate program that runs the 2D avatar that Astro connects
to over its local WebSocket API — no extra software beyond VTube Studio itself is needed. 
You can download it from either the Steam page or [denchisoft.com](https://denchisoft.com/).

Open VTube Studio and enable the API: **Settings → General → Start API**
(default `127.0.0.1:8001` — this is what Astro expects unless you change it
in Astro's UI Settings).


`Setup the avater to talk`

VTube Studios Settings go to "Microphone settings" → enable "Use microphone" → select "microphone". The default will be the desktop audio
unless you have installed the virtual audio cable, now select "CABLE Output" as the microphone 

Now go to the avatar's Settings at the top left, its next to the icon of a camra.  
scroll down and look for "Mouth smile," and change its input to "VoiceFrequencyPlusMouthSmile," 
then go to "Mouth open" and change its input to "VoiceVolumePlusMouthOpen."


This is entirely optional — skip it if you're not using an avatar.


## Launch order

Start things in this order so each service is ready before Astro tries to
reach it:

1. **Ollama** (unless your using a api) — runs in the background once
   installed; no separate start step needed.
2. **VTube Studio** — only if you're using it. Open it and enable the API
   before starting Astro. You only need to enable the API in VTube Studio
   once — it stays on for future launches.
3. **GPT-SoVITS server** — only if you're using it. Launch `api_v2.py` and
   wait for it to finish loading before starting Astro.
4. **Astro** — run `START.bat` (Windows) 




## How to use 

1. **Install and launch.** Windows: double-click `INSTALL.bat` once, then
   `START.bat` every time after. Anything else: `pip install -r
   requirements.txt`.

2. **Get an LLM connected.** Works out of the box with Ollama running
   locally; the first-run open "Setting" in next to "Tts" then select "LLM"
   If you're using Ollama, to see the list of models you currently
   have, check Astro's terminal for "[ INFO ] Available models:" and enter
   the one of model's name in "Ollama model."

3. **Switch or create a character** from the sidebar dropdown on the left.
   New character can be edited in the Setting → character

4. **Set a voice** In Settings → Character, turn on the voice override at the bottom of the character
   you want this on, set its TTS engine. for GPT-SoVITS drop the reference in and transcribe the audio,if you use the 1.wav in voice_refs file I have transcribe the audio for you in the text file just cope and past into "Reference audio's transcript text" 
   selected but not configured, that character stays silent.


5. **Link VTube Studio** open setting and go to VTube Studio, Enable VTube Studio control the go to the VTube Studio app, you sould see a popup says "Astro v" 
 if you dont the host 127.0.0.1 or port are wrong.


6. **Watch it respond** — spoken aloud (if TTS is on), with a live mood
   badge and matching VTube Studio expression. see [Expressions](#Expressions) then move to `How to use 5.`


7. **Talk to a character** — type and hit Enter, or use the Mic button.

8. **Switch or create a character** from the sidebar dropdown on the left.

9. **Open Settings** (top bar) for everything else — LLM, TTS, VTube
   Studio, Expressions, Stream, and Memory.

10. **Optional: go live** — see `Astro_V_Guide_Booklet.docx` Section 6 for
   the full OBS + VTube Studio streaming setup.

11. **Link chats** open Settings and go to Stream; For Youtube you wii need to input the YouTube API key and channel id 
you got when doing `YouTube, Twitch and Kick setup`
API key + Channel ID means the app auto-detects whatever's live on your channel.
For both Twitch and Kick, the only thing required to start listening is to input your channel name.


`You can change any info be opening the setting` 

If something's not connecting, check Astro's UI → Settings → LLM and
confirm the provider is Ollama and the URL/model match what you
installed. Astro checks this endpoint on startup and will warn in the
console if no models are found.









Then open `http://localhost:5000` (it should open automatically on Windows).

By default it talks to Ollama at `localhost:11434` with no TTS setup required
(browser engine) — should work the moment Ollama is running, no other config
needed. Everything else (Piper, GPT-SoVITS, OpenAI/Gemini, Twitch/YouTube/Kick,
VTube Studio) is opt-in from Settings.


   


## Expressions
virtual mic
This isn't a guide on how to create new expressions in VTube Studio — see VTube Studio's own guide for that. For this walkthrough I'll use one of VTube Studio's base avatars, named "Akari." Note that expression filenames differ from avatar to avatar but they are always .json file type. 

1. Open the Expressions tab. In the Astro V control panel (browser), go to Settings → Expressions. Make sure the avatar you want to use is already loaded in VTube Studio.

2. Check the avatars expression exist, Clicking "Refresh model's real expression names" — this pulls up a list of the avatar's expression (.exp3.json) files. For Akari, you should see something like SignAngry.exp3.json, SignShock.exp3.json, EyesCry.exp3.json, and EyesLove.exp3.json. If nothing shows up, the avatar you're using likely doesn't have any expressions set up.

3. To Test them. Use "List my model's hotkeys" at the bottom of the tab, to test an expression press "trigger" and confirm it actually shows up on your Avatar.

the Heart Eyes (ToggleExpression) corresponds to EyesLove.exp3.json toggle expression/hotkey. This hotkey is inside of Vtube Studios it works like this:
  Heart Eyes hotkey
      ↓
Expression:
  EyesLove.exp3.json
      ↓
Live2D model:
  applies/removes the heart-eyes parameters
(it is possible a Avatar has ".json" files but no hotkey is setup in VTube Studio)

4. You should have a list of ".json" files and have confirmed the hotkeys. I will now walk you through no how to connect Astros Expression system to VTube Studio.
I'm going to setup Cry
Find the "sad" mood panel into the file name "EyesCry.exp3.json" For trigger keywords (the bar below where .json files go), pick whatever fits — for example: sorry, forgive, lonely, miss, wish, unfortunate, that's sad, poor, hurt. When the character use a one of the Trigger keywords that activate the expression linked to the .exp3.json fileand tells VTube Studio to activate the related hotkey. 

(it is possible a Avatar has ".json" files but no hotkey setup in VTube Studio,)


See `Astro_V_Guide_Booklet.docx` for a much more detailed walkthrough of
every one of these, with diagrams.



## Requirements

**Core (needed to run Astro at all):**

- Python 3.10+ with pip (the code uses `X | None` type hints, which need
  3.10 or newer — `START.bat` prompts for 3.11+ to be safe).
- Windows: nothing else to install — just `INSTALL.bat` / `START.bat`.
  Anything else: `pip install -r requirements.txt` then `python server.py`.
- A running LLM backend — by default [Ollama](https://ollama.com) at
  `localhost:11434` (free, local, no key; Llama 3 is recommended if your PC can handle it); OpenAI or Gemini also work with
  your own API key.
- A modern desktop browser (Chrome recommended) — the mic input and the
  default Browser TTS engine both rely on the browser's Web Speech API.

**Optional, only if you turn the feature on in Settings:**

- [VTube Studio](https://denchisoft.com/) (desktop app, API enabled) — for
  avatar expression control and mouth-flap.
- A Piper binary + `.onnx` voice file — if you pick Piper as a character's
  TTS engine.
- A running [GPT-SoVITS](https://github.com/RVC-Boss/GPT-SoVITS) server +
  reference voice clip — if you pick GPT-SoVITS as a character's TTS engine.
  This project also includes an example `voice_refs` folder containing a sample
  reference `.wav` and its transcript. If you want, you can simply copy the
  `voice_refs` folder into your GPT-SoVITS folder and use the included files as
  an example for setting up your own reference voice.
- A free YouTube Data API v3 key — only for YouTube chat listening (Twitch
  and Kick need no key).
- A virtual audio cable (e.g. [VB-Cable](https://vb-audio.com/Cable/)) — for
  real waveform-driven VTS lip sync, or for routing the character's voice
  into OBS on its own track.
- OBS Studio — only if you're streaming.

## Output

- **In the panel** — the reply streams in as text, the mood badge updates,
  and status indicators show what's connected.
- **Spoken audio** — if TTS is on, played back through the browser tab.
- **On your VTube Studio model** (if connected) — an expression switch and
  a mouth-flap pulse while the reply is spoken.
- **In stream chat** (if enabled) — voice-only replies to mentions/questions;
  nothing is ever typed back into your actual Twitch/YouTube/Kick chat.
- **On disk** — `config.json`, `characters.json`, the memory store,
  `.vts_auth_token`, and an optional backup JSON export.

## Files

| File | What it does |
|---|---|
| `server.py` | Flask backend — LLM calls, TTS dispatch, Twitch/YouTube/Kick, VTS, routes |
| `templates/control.html` | The web control panel UI |
| `memory.py` | Per-user fact memory (unchanged logic from v8) |
| `vtube_studio.py` | VTube Studio WebSocket client (unchanged logic from v8) |
| `expressions.py` | Keyword → emotion detection, drives VTS + the mood badge |
| `config.json` | All settings — generated on first run, edit via Settings instead of by hand |
| `characters.json` | All characters and which one is active — generated on first run, edit via Settings → Character instead of by hand |
| `Astro_V_Guide_Booklet.docx` | The full illustrated guide — every settings tab, VTS integration internals, mood system, OBS streaming setup |

## Performance: key points

- **Llama 3:** Astro was built/tested with Llama 3 through Ollama. If your PC can handle it comfortably, this is the recommended model family.
- **Use the GPU:** Run `nvidia-smi` while generating to confirm your NVIDIA GPU is being used. For Ollama, `ollama ps` should ideally show `100% GPU`; CPU/GPU splitting usually means the model is too large for available VRAM.
- **Keep Ollama warm:** Leave Ollama running so the model stays loaded instead of paying a cold-start delay each time.
- **Choose a model that fits:** A smaller/quantized model that fits comfortably can be faster than a larger model that spills work into system RAM/CPU.
- **Keep context short:** Less conversation history and shorter character instructions/memory mean less prompt processing.
- **GPT-SoVITS:** Keep the API server running, use GPU inference and half precision where supported, and use a clean reference clip around 3–10 seconds.
- **Keep speech short:** Shorter replies can begin speaking sooner; split very long replies where practical.
- **Free VRAM:** Close browsers and other GPU-heavy applications if VRAM is tight.
- **Check GPT-SoVITS:** Its startup output should show `device: cuda` and, where enabled, `is_half: True`. `device: cpu` means it is running on CPU.

## Troubleshoot


**`400 Bad Request`**

If the reference path already looks right, double-check the exact
folder/file name (singular vs. plural, spelling, capitalization) —
GPT-SoVITS checks the path relative to whatever folder you launched
`api_v2.py` from, so a typo there is the usual culprit. The file tree
should look like `GPT-SoVITS\voice_refs`.

**`[ERROR] HTTPConnectionPool(host='localhost', port=11434): Read timed out. (read timeout=60)`**
The first response will take longer
Try sending the input another couple of times. If you keep getting this
error, the LLM is taking too long to generate a response — this can
happen for several reasons, but hardware is the most likely one. For
some fixes, see [Reducing LLM response time](#reducing-llm-response-time).

In Astro's terminal:
"[ WARN ] Ollama not detected — start it with: ollama app" means Ollama is not open. If it is open,
"[ INFO ] Available models:" shows the Ollama models you have downloaded
and can use.

For the full guide and more detail open `Astro_V_Guide_Booklet.docx`.
