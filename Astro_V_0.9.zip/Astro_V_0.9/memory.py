"""
memory.py — Per-character, per-user persistent memory for the AI.

Storage shape is now nested: character -> username -> [fact, fact, ...].
Each character remembers its own things about you (and about anyone else it
talks to, e.g. Twitch viewers) — Mey and Kaname build up separate memories
even if you tell them both the same thing.

Each fact carries:
  - created:    when it was first learned
  - last_seen:  when it was last reinforced (mentioned again)
  - hits:       how many times it's come up

A relevance score is computed from these — recent/reinforced facts score
high, facts that haven't come up in a long time decay toward zero. When a
user's fact count (within one character) exceeds max_facts, the
LOWEST-scoring facts are dropped first (not just the oldest), and facts that
have decayed almost to nothing AND are old are pruned outright even under
the cap.

Individual facts within a user's list are normalized on load — each is
upgraded to the full {"text", "created", "last_seen", "hits"} object shape
if it isn't already, so any missing metadata gets sensible defaults instead
of failing to load.
"""

import json
import logging
import os
import time

import requests

logger = logging.getLogger(__name__)

SECONDS_PER_DAY = 86400.0
MIN_SCORE_TO_KEEP = 0.05     # facts below this score...
STALE_MULTIPLE = 3           # ...and older than (half_life * this many days) get pruned outright


class MemoryManager:
    """Manages per-character, per-user fact storage, extraction, decay/relevance, and injection."""

    def __init__(self, memory_file: str = "memory.json", max_facts: int = 10,
                 ollama_url: str = "http://localhost:11434", ollama_model: str = "",
                 decay_half_life_days: float = 30) -> None:
        self.memory_file = memory_file
        self.max_facts   = max_facts
        self.ollama_url  = ollama_url.rstrip("/")
        self.ollama_model = ollama_model
        self.decay_half_life_days = max(1, decay_half_life_days)
        self._data: dict[str, dict[str, list[dict]]] = self._load()

    # ------------------------------------------------------------------
    # Scoring
    # ------------------------------------------------------------------

    def _score(self, fact: dict, now: float = None) -> float:
        """Higher = more relevant. Combines reinforcement (hits) with
        recency decay since the fact was last seen — a fact mentioned once
        three months ago scores lower than one mentioned twice last week."""
        now = now if now is not None else time.time()
        age_days = max(0.0, (now - fact.get("last_seen", fact.get("created", now))) / SECONDS_PER_DAY)
        decay = 0.5 ** (age_days / self.decay_half_life_days)
        hits = fact.get("hits", 1)
        reinforcement = 1 + min(hits - 1, 5) * 0.3   # diminishing returns, caps out around 2.5x
        return reinforcement * decay

    def _rank(self, character: str, username: str, now: float = None) -> list[dict]:
        now = now if now is not None else time.time()
        facts = self._data.get(character, {}).get(username, [])
        return sorted(facts, key=lambda f: self._score(f, now), reverse=True)

    # ------------------------------------------------------------------
    # Public API — every call is scoped to one character
    # ------------------------------------------------------------------

    def get_prompt_injection(self, character: str, username: str, display_name: str = None) -> str:
        """`username` is the storage key (must be unique per person — may be
        a platform-prefixed id like 'youtube:UC1234' and not fit for
        display). `display_name`, if given, is what's shown to the LLM in
        the 'What you know about X' line instead — defaults to `username`
        for callers that don't need the distinction (e.g. the streamer)."""
        ranked = self._rank(character, username)
        if not ranked:
            return ""
        joined = "\n".join(f"- {f['text']}" for f in ranked)
        return (
            f"\n\nWhat you know about {display_name or username}:\n{joined}\n"
            f"Use this naturally — never announce that you remember it."
        )

    def update(self, character: str, username: str, user_msg: str, ai_reply: str) -> None:
        bucket = self._data.setdefault(character, {})
        existing = bucket.get(username, [])
        new_texts = self._extract_facts(username, user_msg, ai_reply, [f["text"] for f in existing])
        now = time.time()
        changed = False
        if new_texts:
            for text in new_texts:
                match = self._find_similar(text, existing)
                if match is not None:
                    match["last_seen"] = now
                    match["hits"] = match.get("hits", 1) + 1
                else:
                    existing.append({"text": text, "created": now, "last_seen": now, "hits": 1})
                changed = True
            existing = self._deduplicate(existing)
        existing = self._trim(existing, now)
        if changed or len(existing) != len(bucket.get(username, [])):
            bucket[username] = existing
            self._save()
            logger.info("Memory updated for %s (as remembered by %s): %s",
                        username, character, [f["text"] for f in existing])

    def get_facts(self, character: str, username: str) -> list[str]:
        """Plain fact text, strongest/most relevant first — used for prompt
        display and anywhere the old string-list shape is expected."""
        return [f["text"] for f in self._rank(character, username)]

    def get_facts_detailed(self, character: str, username: str) -> list[dict]:
        """Same facts with relevance score (0-1ish), reinforcement count, and
        age in days — for a UI that wants to show what's fresh vs. fading."""
        now = time.time()
        out = []
        for f in self._rank(character, username, now):
            age_days = (now - f.get("last_seen", f.get("created", now))) / SECONDS_PER_DAY
            out.append({
                "text": f["text"],
                "score": round(self._score(f, now), 3),
                "hits": f.get("hits", 1),
                "age_days": round(age_days, 1),
            })
        return out

    def clear_user(self, character: str, username: str) -> None:
        """Wipes what one character remembers about one user, leaving what
        every other character remembers about them untouched."""
        bucket = self._data.get(character)
        if bucket and username in bucket:
            del bucket[username]
            self._save()

    def clear_character(self, character: str) -> int:
        """Wipes EVERYTHING a given character remembers — every user it has
        ever talked to. Returns how many users' memories were cleared."""
        bucket = self._data.get(character)
        if not bucket:
            return 0
        count = len(bucket)
        del self._data[character]
        self._save()
        return count

    def delete_fact(self, character: str, username: str, fact: str) -> bool:
        bucket = self._data.get(character, {})
        facts = bucket.get(username, [])
        match = next((f for f in facts if f["text"] == fact), None)
        if match is None:
            return False
        facts.remove(match)
        if facts:
            bucket[username] = facts
        elif username in bucket:
            del bucket[username]
        self._save()
        return True

    def clear_all(self) -> None:
        self._data = {}
        self._save()

    def trim_to_max(self) -> None:
        """Re-apply max_facts + decay pruning to everything already stored,
        across every character (e.g. after max_facts or the decay rate is
        changed in Settings)."""
        now = time.time()
        changed = False
        for character, bucket in self._data.items():
            for username, facts in bucket.items():
                trimmed = self._trim(facts, now)
                if trimmed != facts:
                    bucket[username] = trimmed
                    changed = True
        if changed:
            self._save()

    def all_users(self, character: str) -> dict[str, list[str]]:
        """Users this specific character has memory of, and what it
        remembers about each."""
        bucket = self._data.get(character, {})
        return {u: [f["text"] for f in facts] for u, facts in bucket.items()}

    def all_characters(self) -> list[str]:
        """Every character name that has any memory stored at all — used to
        offer a 'wipe this character's memory' option even for a character
        that isn't the currently active one."""
        return [c for c, bucket in self._data.items() if bucket]

    # ------------------------------------------------------------------
    # Trimming / pruning
    # ------------------------------------------------------------------

    def _trim(self, facts: list[dict], now: float) -> list[dict]:
        stale_after = self.decay_half_life_days * STALE_MULTIPLE
        kept = []
        for f in facts:
            age_days = (now - f.get("created", now)) / SECONDS_PER_DAY
            if self._score(f, now) < MIN_SCORE_TO_KEEP and age_days > stale_after:
                continue  # decayed to irrelevance and old enough that it's genuinely stale — drop
            kept.append(f)
        if len(kept) > self.max_facts:
            kept = sorted(kept, key=lambda f: self._score(f, now), reverse=True)[: self.max_facts]
        return kept

    @staticmethod
    def _find_similar(text: str, facts: list[dict]):
        """Cheap same-fact check (exact or substring match, case-insensitive)
        so an obviously-repeated fact reinforces instead of duplicating.
        Genuine near-duplicate *phrasings* are still caught by the LLM merge
        in _deduplicate."""
        tl = text.lower().strip()
        best = None
        for f in facts:
            fl = f["text"].lower().strip()
            if fl == tl or fl in tl or tl in fl:
                if best is None or len(fl) > len(best["text"]):
                    best = f
        return best

    # ------------------------------------------------------------------
    # Extraction
    # ------------------------------------------------------------------

    def _extract_facts(self, username, user_msg, ai_reply, existing_texts):
        existing_block = "\n".join(f"- {f}" for f in existing_texts) if existing_texts else "(none yet)"
        prompt = (
            f"You are a fact extractor. Read the conversation below and extract "
            f"any NEW personal facts about the user called '{username}' "
            f"(e.g. their name, hobbies, preferences, location, job, age).\n\n"
            f"Already known facts (do NOT repeat these):\n{existing_block}\n\n"
            f"User said: {user_msg}\n"
            f"AI replied: {ai_reply}\n\n"
            f'Reply ONLY with a JSON array of short fact strings e.g. ["likes horror games"]. '
            f"If no new facts, reply with: []"
        )
        try:
            resp = requests.post(
                f"{self.ollama_url}/api/chat",
                json={"model": self.ollama_model, "messages": [{"role": "user", "content": prompt}], "stream": False},
                timeout=15,
            )
            if resp.status_code != 200:
                return []
            content = resp.json().get("message", {}).get("content", "").strip()
            if content.startswith("```"):
                content = content.split("```")[1]
                if content.startswith("json"):
                    content = content[4:]
            facts = json.loads(content)
            return [str(f).strip() for f in facts if f] if isinstance(facts, list) else []
        except (json.JSONDecodeError, requests.RequestException) as e:
            logger.warning("Memory extraction error: %s", e)
            return []

    def _deduplicate(self, facts: list[dict]) -> list[dict]:
        """Merges near-duplicate phrasings via the LLM, then reconciles the
        merged text back onto the original fact objects so timestamps/hits
        aren't lost — a merged fact inherits its best-matching source's
        metadata; a genuinely new phrase (the merge coined something not in
        the input) starts fresh."""
        if len(facts) <= 1:
            return facts
        texts = [f["text"] for f in facts]
        prompt = (
            "Merge any facts that mean the same thing into one concise fact. Keep genuinely different facts.\n\n"
            "Input:\n" + "\n".join(f"- {t}" for t in texts) +
            '\n\nReply ONLY with a JSON array e.g. ["likes anime"]. No explanation.'
        )
        try:
            resp = requests.post(
                f"{self.ollama_url}/api/chat",
                json={"model": self.ollama_model, "messages": [{"role": "user", "content": prompt}], "stream": False},
                timeout=15,
            )
            if resp.status_code != 200:
                return facts
            content = resp.json().get("message", {}).get("content", "").strip()
            if content.startswith("```"):
                content = content.split("```")[1]
                if content.startswith("json"):
                    content = content[4:]
            merged_texts = json.loads(content)
            if not isinstance(merged_texts, list) or not merged_texts:
                return facts
        except (json.JSONDecodeError, requests.RequestException) as e:
            logger.warning("Dedup error: %s", e)
            return facts

        now = time.time()
        used_ids, out = set(), []
        for text in merged_texts:
            text = str(text).strip()
            if not text:
                continue
            match = None
            tl = text.lower()
            for f in facts:
                if id(f) in used_ids:
                    continue
                fl = f["text"].lower()
                if fl == tl or fl in tl or tl in fl:
                    if match is None or len(f["text"]) > len(match["text"]):
                        match = f
            if match is not None:
                used_ids.add(id(match))
                out.append({"text": text, "created": match["created"],
                            "last_seen": match["last_seen"], "hits": match.get("hits", 1)})
            else:
                out.append({"text": text, "created": now, "last_seen": now, "hits": 1})
        return out if out else facts

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _load(self) -> dict[str, dict[str, list[dict]]]:
        if not os.path.exists(self.memory_file):
            return {}
        try:
            with open(self.memory_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict) or not data:
                return {}
            # Expected shape: character -> username -> list of fact objects.
            return {
                character: {u: self._upgrade_user_facts(facts) for u, facts in bucket.items()}
                for character, bucket in data.items() if isinstance(bucket, dict)
            }
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Could not load memory file: %s", e)
            return {}

    @staticmethod
    def _upgrade_user_facts(facts) -> list[dict]:
        """Old format was a flat list of strings. Upgrade in place, on load,
        to the timestamped object format — every migrated fact starts with a
        clean slate (created = last_seen = now, hits = 1) since we have no
        history for it, and will start decaying/reinforcing normally from
        here on."""
        if not isinstance(facts, list):
            return []
        now = time.time()
        out = []
        for f in facts:
            if isinstance(f, dict) and "text" in f:
                out.append({
                    "text": f["text"],
                    "created": f.get("created", now),
                    "last_seen": f.get("last_seen", f.get("created", now)),
                    "hits": f.get("hits", 1),
                })
            elif isinstance(f, str) and f.strip():
                out.append({"text": f.strip(), "created": now, "last_seen": now, "hits": 1})
        return out

    def _save(self) -> None:
        try:
            with open(self.memory_file, "w", encoding="utf-8") as f:
                json.dump(self._data, f, indent=2, ensure_ascii=False)
        except OSError as e:
            logger.warning("Could not save memory file: %s", e)
